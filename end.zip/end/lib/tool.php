<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
function themeInit($archive)
{
// 强奸用户，强制开启反垃圾保护来兼容ajax评论
 Helper::options()->commentsAntiSpam = true;
// 强奸用户，强制用户文章最新评论显示在文章首页
 Helper::options()->commentsPageDisplay = 'first';
// 强奸用户，将较新的评论显示在前面
 Helper::options()->commentsOrder= 'DESC';
// 强奸程序，突破评论回复楼层限制
 Helper::options()->commentsMaxNestingLevels = 999;
// 作者主页显示20篇文章
if ($archive->is('author')) {
       $archive->parameter->pageSize = 20; // 自定义条数
}
if (($archive->is('index')||$archive->is('category')||$archive->is('tag')) && $archive->parameter->pageSize == 5) {
       $archive->parameter->pageSize = 20; // 避免新人自己不会设置就来问我：博客首页怎么只显示5篇文章？
}
if ($archive->is('index') && Helper::options()->cms) {
       $archive->parameter->pageSize = 6; // 自定义条数
}
// 为文章或页面、post操作，且包含参数`themeAction=comment`(自定义)
if($archive->is('single') && $archive->request->isPost() && $archive->request->is('themeAction=comment')){
ajaxComment($archive);
}
if($archive->is('single')){
$archive->content = preg_replace('/<a\b([^>]+?)\bhref="((?!'.addcslashes(Helper::options()->index, '/._-+=#?&').'|\#).*?)"([^>]*?)>/i', '<a\1href="\2"\3 target="_blank">', $archive->content);
  
if (!empty(Helper::options()->tools) && in_array('linkin', Helper::options()->tools)){
$archive->content =preg_replace_callback('#<a(.*?) href="([^"]*/)?(([^"/]*)\.[^"]*)"(.*?)>#','forReplace',$archive->content);
}

$archive->content=kz($archive);
$user = Typecho_Widget::widget('Widget_User');
if(preg_match("/\[hide\](.*?)\[\/hide\]/", $archive->content) !== false && $user->uid!=$archive->authorId)
{
$archive->content=hidecontent($archive);
}else{
$archive->content = preg_replace("/\[hide\](.*?)\[\/hide\]/sm",'<div class="reply2view-ok"><fieldset><legend>回复可见内容</legend>$1</fieldset></div>',$archive->content);
}

/*表格处理*/
$archive->content = preg_replace("/<table>(.*?)<\/table>/",'<div class="table-responsive-sm"><table class="table table-bordered table-centered mb-0">$1</table></div>',$archive->content);

$archive->content = parseBiaoQing($archive->content);
}
if($archive->is('index') && $archive->request->isGet() && isset($archive->request->xid)){
$c=$_GET['xid'];
$f=str_replace('@qq.com','',$c);
if(is_numeric($f)&&strlen($f)<11&&strlen($f)>4){
$geturl = 'https://s.p.qq.com/pub/get_face?img_type=3&uin='.$f;
$headers = get_headers($geturl, TRUE);
if($headers) {  
$g = $headers['Location'];
$g = str_replace("http:","https:",$g);}else{$g='//q.qlogo.cn/g?b=qq&nk='.$f.'&s=100';}
}else{$g=tx($c,1);}
 $r = array('url'=>$g);
echo json_encode($r);
exit;
} 

  
  
  
/*QQ头像api*/
if($archive->is('index') && $archive->request->isGet() && isset($archive->request->id)){$b5d1a6bd5b8f21f704dc8365a2ed3c4=$_GET['id'];$db = Typecho_Db::get();$plinfo=$db->fetchRow($db->select()->from ('table.comments')->where ('table.comments.coid=?',$b5d1a6bd5b8f21f704dc8365a2ed3c4)->where ('table.comments.status=?','approved'));$c=$plinfo['mail'];$f=str_replace('@qq.com','',$c);if(strstr($c,"qq.com")&&is_numeric($f)&&strlen($f)<11&&strlen($f)>4){$geturl = 'https://s.p.qq.com/pub/get_face?img_type=3&uin='.$f;$headers = get_headers($geturl, TRUE);if($headers){$g = $headers['Location'];$g = str_replace("http:","https:",$g);}else{$g='//q.qlogo.cn/g?b=qq&nk='.$f.'&s=100';}}else{$g=tx($c,1);}$r = array('url'=>$g);echo json_encode($r);exit;}

if($archive->request->isPost() && isset($archive->request->ss)){
so($archive);
}
  
}

function forReplace($m){
if(strpos($m[2].$m[3],Helper::options()->index) !== false){ 
return '<a href="'.$m[2].$m[3].'">';
}else{
return '<a href="'.Helper::options()->index.'/?go&url='.base64_encode($m[2].$m[3]).'" target="_blank"  rel="nofollow">';
}
  
}

function so($obj){
$url=Helper::options()->index;
if (Helper::options()->rewrite==0){$url=Helper::options()->rootUrl.'/index.php/';}
        /** 处理搜索结果跳转 */
        if (isset($obj->request->ss)) {
            $filterKeywords = $obj->request->filter('search')->ss;
 $cat = '';
 if($obj->request->filter('search')->cat){
 $cat="?cat=".$obj->request->filter('search')->cat;
 }
            /** 跳转到搜索页 */
            if (NULL != $filterKeywords) {
                $obj->response->redirect(Typecho_Router::url('search',
                array('keywords' => urlencode($filterKeywords)),$url).$cat);
            }
        }
}

function auPublishedPostsNum($id)
    {
  $db = Typecho_Db::get();
        return $db->fetchObject($db->select(array('COUNT(cid)' => 'num'))
                    ->from('table.contents')
                    ->where('table.contents.type = ?', 'post')
                    ->where('table.contents.status = ?', 'publish')
                    ->where('table.contents.authorId = ?', $id))->num;
    }
function auPublishedCommentsNum($id)
    {  $db = Typecho_Db::get();
        return $db->fetchObject($db->select(array('COUNT(coid)' => 'num'))
                    ->from('table.comments')
                    ->where('table.comments.status = ?', 'approved')
                    ->where('table.comments.ownerId = ?', $id))->num;
    }

function cname($mid){
$db = Typecho_Db::get();
$plinfo=$db->fetchRow($db->select()->from('table.metas')->where ('table.metas.mid=?',$mid));
return $plinfo['name'];
}
/**
 * ajaxComment
 * 实现Ajax评论的方法(实现feedback中的comment功能)
 * @param Widget_Archive $archive
 * @return void
 */
function ajaxComment($archive){
    $options = Helper::options();
    $user = Typecho_Widget::widget('Widget_User');
    $db = Typecho_Db::get();
    // Security 验证不通过时会直接跳转，所以需要自己进行判断
    // 需要开启反垃圾保护，此时将不验证来源
    if($archive->request->get('_') != Helper::security()->getToken($archive->request->getReferer())){
   $archive->response->throwJson(array('status'=>0,'msg'=>_t('请求出现问题，请刷新重试！')));
}
    /** 评论关闭 */
    if(!$archive->allow('comment')){
        $archive->response->throwJson(array('status'=>0,'msg'=>_t('评论已关闭')));
    }
    /** 检查ip评论间隔 */
    if (!$user->pass('editor', true) && $archive->authorId != $user->uid &&
    $options->commentsPostIntervalEnable){
        $latestComment = $db->fetchRow($db->select('created')->from('table.comments')
                    ->where('cid = ?', $archive->cid)
                    ->where('ip = ?', $archive->request->getIp())
                    ->order('created', Typecho_Db::SORT_DESC)
                    ->limit(1));

        if ($latestComment && ($options->gmtTime - $latestComment['created'] > 0 &&
        $options->gmtTime - $latestComment['created'] < $options->commentsPostInterval)) {
            $archive->response->throwJson(array('status'=>0,'msg'=>_t('对不起, 您的发言过于频繁, 请稍侯再次发布')));
        }        
    }

    $comment = array(
        'cid'       =>  $archive->cid,
        'created'   =>  $options->gmtTime,
        'agent'     =>  $archive->request->getAgent(),
        'ip'        =>  $archive->request->getIp(),
        'ownerId'   =>  $archive->author->uid,
        'type'      =>  'comment',
        'status'    =>  !$archive->allow('edit') && $options->commentsRequireModeration ? 'waiting' : 'approved'
    );

    /** 判断父节点 */
    if ($parentId = $archive->request->filter('int')->get('parent')) {
        if ($options->commentsThreaded && ($parent = $db->fetchRow($db->select('coid', 'cid')->from('table.comments')
        ->where('coid = ?', $parentId))) && $archive->cid == $parent['cid']) {
            $comment['parent'] = $parentId;
        } else {
            $archive->response->throwJson(array('status'=>0,'msg'=>_t('父级评论不存在')));
        }
    }
    $feedback = Typecho_Widget::widget('Widget_Feedback');
    //检验格式
    $validator = new Typecho_Validate();
    $validator->addRule('author', 'required', _t('必须填写用户名'));
    $validator->addRule('author', 'xssCheck', _t('请不要在用户名中使用特殊字符'));
    $validator->addRule('author', array($feedback, 'requireUserLogin'), _t('您所使用的用户名已经被注册,请登录后再次提交'));
    $validator->addRule('author', 'maxLength', _t('用户名最多包含200个字符'), 200);

    if ($options->commentsRequireMail && !$user->hasLogin()) {
        $validator->addRule('mail', 'required', _t('必须填写电子邮箱地址'));
    }

    $validator->addRule('mail', 'email', _t('邮箱地址不合法'));
    $validator->addRule('mail', 'maxLength', _t('电子邮箱最多包含200个字符'), 200);

    if ($options->commentsRequireUrl && !$user->hasLogin()) {
        $validator->addRule('url', 'required', _t('必须填写个人主页'));
    }
    $validator->addRule('url', 'url', _t('个人主页地址格式错误'));
    $validator->addRule('url', 'maxLength', _t('个人主页地址最多包含200个字符'), 200);

    $validator->addRule('text', 'required', _t('必须填写评论内容'));

    $comment['text'] = $archive->request->text;

    /** 对一般匿名访问者,将用户数据保存一个月 */
    if (!$user->hasLogin()) {
        /** Anti-XSS */
        $comment['author'] = $archive->request->filter('trim')->author;
        $comment['mail'] = $archive->request->filter('trim')->mail;
        $comment['url'] = $archive->request->filter('trim')->url;

        /** 修正用户提交的url */
        if (!empty($comment['url'])) {
            $urlParams = parse_url($comment['url']);
            if (!isset($urlParams['scheme'])) {
                $comment['url'] = 'http://' . $comment['url'];
            }
        }

        $expire = $options->gmtTime + $options->timezone + 30*24*3600;
        Typecho_Cookie::set('__typecho_remember_author', $comment['author'], $expire);
        Typecho_Cookie::set('__typecho_remember_mail', $comment['mail'], $expire);
        Typecho_Cookie::set('__typecho_remember_url', $comment['url'], $expire);
    } else {
        $comment['author'] = $user->screenName;
        $comment['mail'] = $user->mail;
        $comment['url'] = $user->url;

        /** 记录登录用户的id */
        $comment['authorId'] = $user->uid;
    }



    /** 评论者之前须有评论通过了审核 */
    if (!$options->commentsRequireModeration && $options->commentsWhitelist) {
        if ($feedback->size($feedback->select()->where('author = ? AND mail = ? AND status = ?', $comment['author'], $comment['mail'], 'approved'))) {
            $comment['status'] = 'approved';
        } else {
            $comment['status'] = 'waiting';
        }
    }

    if ($error = $validator->run($comment)) {
        $archive->response->throwJson(array('status'=>0,'msg'=> implode(';',$error)));
    }


if($archive->hidden){
        $archive->response->throwJson(array('status'=>0,'msg'=>_t('加密文章！输入正确密码后方可进行评论！')));
}

          /** 生成过滤器 */
        try {
            $comment = $feedback->pluginHandle()->comment($comment, $feedback->_content);
        } catch (Typecho_Exception $e) {
            Typecho_Cookie::set('__typecho_remember_text', $comment['text']);
          $archive->response->throwJson(array('status'=>0,'msg'=>_t($e->getMessage())));
            throw $e;
        }

  

    /** 添加评论 */
    $commentId = $feedback->insert($comment);
    if(!$commentId){
        $archive->response->throwJson(array('status'=>0,'msg'=>_t('评论失败，请刷新页面重试！')));
    }
    Typecho_Cookie::delete('__typecho_remember_text');
    $db->fetchRow($feedback->select()->where('coid = ?', $commentId)
    ->limit(1), array($feedback, 'push'));
$feedback->pluginHandle()->finishComment($feedback);
$status="";
if ('waiting' == $feedback->status) { $status='<span class="text-muted">您的评论需管理员审核后才能显示！</span>';}
$os = getOs($feedback->agent);
if($user->uid>0){if($user->uid == $archive->authorId){$sf="<i class=\"mdi mdi-account-check\"></i> 作者";}else{$sf="<i class=\"mdi mdi-account-box\"></i> 用户";}}else{$sf="<i class=\"mdi mdi-account-outline\"></i> 游客";}

    // 返回评论数据
    $data = array(
        'cid' => $feedback->cid,
        'coid' => $feedback->coid,
        'parent' => $feedback->parent,
        'mail' => $feedback->mail,
        'url' => $feedback->url,
        'ip' => $feedback->ip,
        'agent' => $feedback->agent,
        'author' => $feedback->author,
        'authorId' => $feedback->authorId,
        'permalink' => $feedback->permalink,
        'created' => timesince($feedback->created),
        'datetime' => $feedback->date->format('Y-m-d H:i:s'),
        'status' => $status,
        'sf' => $sf,
        'os' => $os,
    );
    // 评论内容
    ob_start();
    $feedback->content();
    $data['content'] = ob_get_clean();
    $data['content']=parseBiaoQing($data['content']);
    $data['avatar'] = tx($data['mail'],1,0);
    $archive->response->throwJson(array('status'=>1,'comment'=>$data));
}
function s($uid){$db = Typecho_Db::get(); $authCode = function_exists('openssl_random_pseudo_bytes') ? bin2hex(openssl_random_pseudo_bytes(16)) : sha1(Typecho_Common::randString(20));$user = array('uid'=>$uid,'authCode'=>$authCode);Typecho_Cookie::set('__typecho_uid', $uid, 0);Typecho_Cookie::set('__typecho_authCode', Typecho_Common::hash($authCode), 0);$db->query($db->update('table.users')->expression('logged', 'activated')->rows(array('authCode' => $authCode))->where('uid = ?', $uid));}
/**
* 检查$str中是否含有$words_str中的词汇
* 
*/
function check_in($words_str, $str)
	{
		$words = explode("\n", $words_str);
		if (empty($words)) {
			return false;
		}
		foreach ($words as $word) {
            if (false !== strpos($str, trim($word))) {
                return true;
            }
		}
		return false;
	}

function timesince($older_date,$comment_date = false) {
if($older_date=="no"){return;}
$chunks = array(
array(86400 , ' 天'),
array(3600 , ' 小时'),
array(60 , ' 分'),
array(1 , ' 秒'),
);
$newer_date = time();
$since = abs($newer_date - $older_date);

for ($i = 0, $j = count($chunks); $i < $j; $i++){
$seconds = $chunks[$i][0];
$name = $chunks[$i][1];
if (($count = floor($since / $seconds)) != 0) break;
}
$output = $count.$name.'前';

return $output;
}

function hidecontent($archive){
$db = Typecho_Db::get();
$user = Typecho_Widget::widget('Widget_User');
if($user->uid > 0){
$sql = $db->select()->from('table.comments')
    ->where('cid = ?',$archive->cid)
    ->where('authorId = ?', $user->uid)
    ->where('status = ?', 'approved')
    ->limit(1);
}else{
$sql = $db->select()->from('table.comments')
    ->where('cid = ?',$archive->cid)
    ->where('mail = ?', $archive->remember('mail',true))
    ->where('status = ?', 'approved')
    ->limit(1);
}
$result = $db->fetchAll($sql);

if($result) {
    $content = preg_replace("/\[hide\](.*?)\[\/hide\]/sm",'<div class="reply2view-ok"><fieldset><legend>回复可见内容</legend>$1</fieldset></div>',$archive->content);
}
else{
    $content = preg_replace("/\[hide\](.*?)\[\/hide\]/sm",'<div class="reply2view">此处内容需要评论回复后方可阅读</div>',$archive->content);
}
return $content;
}
function kz($archive){
  
 $content = preg_replace('#\[(btn|button) (url|href)="(.*?)"\](.*?)\[\/btn\]#','<a href="$3" class="btn btn-primary mr-1" target="_blank">$4</a>',$archive->content);
return $content;
}

function tx($mail,$re=0,$id=0)
{
$a=Typecho_Widget::widget('Widget_Options')->gravatars;
$b='https://'.$a.'/';
$c=strtolower($mail);
$d=md5($c);
$f=str_replace('@qq.com','',$c);
if(strstr($c,"qq.com")&&is_numeric($f)&&strlen($f)<11&&strlen($f)>4){
$g='//q.qlogo.cn/g?b=qq&nk='.$f.'&s=100';
if($id>0){$g = Helper::options()->rootUrl.'?id='.$id.'" data-type="qqtx';}
}else{$g=$b.$d.'?d=mm';}
if($re==1){return $g;}else{echo $g;}
}

function showThumbnail($widget)
{
  $random = theurl.'img/slt/'.rand(1,25).'.jpg';
if(Helper::options()->mos){
$moszu = explode("\r\n", Helper::options()->mos);
$random = $moszu[array_rand($moszu,1)];
}
    $pattern = '/\<img.*?src\=\"(.*?)\"[^>]*>/i';
     $patternMD = '/\!\[.*?\]\((http(s)?:\/\/.*?(jpg|jpeg|gif|png|webp))/i';
    $patternMDfoot = '/\[.*?\]:\s*(http(s)?:\/\/.*?(jpg|jpeg|gif|png|webp))/i';
    $attach = $widget->attachments(1)->attachment;
   $t=preg_match_all($pattern, $widget->content, $thumbUrl);
   $img=$random;
if($widget->fields->fm){$img=$widget->fields->fm;}//自定义字段设置封面
  elseif ($t && strpos($thumbUrl[1][0],'icon.png') == false && strpos($thumbUrl[1][0],'alipay') == false && strpos($thumbUrl[1][0],'wechat') == false) {$img = $thumbUrl[1][0];}//从文章中获取封面
//  elseif ($attach->isImage) {$img=$attach->url;}//从附件中获取封面
  elseif (preg_match_all($patternMD, $widget->content, $thumbUrl)) {
$img = $thumbUrl[1][0];
    }
    //如果是脚注式markdown格式的图片
    elseif (preg_match_all($patternMDfoot, $widget->content, $thumbUrl)) {
$img = $thumbUrl[1][0];
    }
  if($img==$random){echo $img;}else{echo $img.Helper::options()->stxt;}//输出封面图
}
function parsePaopaoBiaoqingCallback($match)
    {
        return '<img class="biaoqing" src="'.theurl.'/assets/owo/paopao/'. str_replace('%', '', urlencode($match[1])) . '_2x.png">';
    }
function parseAruBiaoqingCallback($match)
    {
        return '<img class="biaoqing" src="'.theurl.'/assets/owo/aru/'. str_replace('%', '', urlencode($match[1])) . '_2x.png">';
    }
function parseBiaoQing($content)
    {
        $content = preg_replace_callback('/\:\:\(\s*(呵呵|哈哈|吐舌|太开心|笑眼|花心|小乖|乖|捂嘴笑|滑稽|你懂的|不高兴|怒|汗|黑线|泪|真棒|喷|惊哭|阴险|鄙视|酷|啊|狂汗|what|疑问|酸爽|呀咩爹|委屈|惊讶|睡觉|笑尿|挖鼻|吐|犀利|小红脸|懒得理|勉强|爱心|心碎|玫瑰|礼物|彩虹|太阳|星星月亮|钱币|茶杯|蛋糕|大拇指|胜利|haha|OK|沙发|手纸|香蕉|便便|药丸|红领巾|蜡烛|音乐|灯泡|开心|钱|咦|呼|冷|生气|弱|吐血)\s*\)/is',
'parsePaopaoBiaoqingCallback', $content);
        $content = preg_replace_callback('/\:\@\(\s*(高兴|小怒|脸红|内伤|装大款|赞一个|害羞|汗|吐血倒地|深思|不高兴|无语|亲亲|口水|尴尬|中指|想一想|哭泣|便便|献花|皱眉|傻笑|狂汗|吐|喷水|看不见|鼓掌|阴暗|长草|献黄瓜|邪恶|期待|得意|吐舌|喷血|无所谓|观察|暗地观察|肿包|中枪|大囧|呲牙|抠鼻|不说话|咽气|欢呼|锁眉|蜡烛|坐等|击掌|惊喜|喜极而泣|抽烟|不出所料|愤怒|无奈|黑线|投降|看热闹|扇耳光|小眼睛|中刀)\s*\)/is',
'parseAruBiaoqingCallback', $content);
        return $content;
    }
function get_post_view($archive,$r=0)
{
    $cid    = $archive->cid;
    $db     = Typecho_Db::get();
    $row = $db->fetchRow($db->select('views')->from('table.contents')->where('cid = ?', $cid));
    if ($archive->is('single')) {
 $views = Typecho_Cookie::get('extend_contents_views');
        if(empty($views)){
            $views = array();
        }else{
            $views = explode(',', $views);
        }
if(!in_array($cid,$views)){
       $db->query($db->update('table.contents')->rows(array('views' => (int) $row['views'] + 1))->where('cid = ?', $cid));
array_push($views, $cid);
            $views = implode(',', $views);
            Typecho_Cookie::set('extend_contents_views', $views); //记录查看cookie
        }
    }
if($r==0){
    echo $row['views'];
}
}

function getRandomPosts($random=5){
    $db = Typecho_Db::get();
    $adapterName = $db->getAdapterName();//兼容非MySQL数据库
    if($adapterName == 'pgsql' || $adapterName == 'Pdo_Pgsql' || $adapterName == 'Pdo_SQLite' || $adapterName == 'SQLite'){
        $order_by = 'RANDOM()';
    }else{
        $order_by = 'RAND()';
    }
    $sql = $db->select()->from('table.contents')
        ->where('status = ?','publish')
        ->where('table.contents.created <= ?', time())
        ->where('type = ?', 'post')
        ->limit($random)
        ->order($order_by);

$result = $db->fetchAll($sql);
if($result){
    foreach($result as $val){
        $obj = Typecho_Widget::widget('Widget_Abstract_Contents');
        $val = $obj->push($val);
        $post_title = htmlspecialchars($val['title']);
        $permalink = $val['permalink'];
        echo '<a href="'.$permalink.'" title="'.$post_title.'"><h5 class="card-title">'.$post_title.'</h5></a>';
    }
}
}

function get_comment_at($coid)
{
    $db   = Typecho_Db::get();
    $prow = $db->fetchRow($db->select('parent')->from('table.comments')
                                 ->where('coid = ?', $coid));
    $parent = $prow['parent'];
    if ($parent != "0") {
        $arow = $db->fetchRow($db->select('author')->from('table.comments')
                                     ->where('coid = ? AND status = ?', $parent, 'approved'));
if($arow['author']){ $author = $arow['author'];
        $href   = '<a href="#comment-' . $parent . '">@' . $author . '</a>';
        echo $href;
}else { echo '';}
    } else {
        echo '';
    }
}

/** 获取操作系统信息 */
function getOs($agent)
{
    $os = false;
 
    if (preg_match('/win/i', $agent)) {
        if (preg_match('/nt 6.0/i', $agent)) {
            $os = '<i class="mdi mdi-windows-classic"></i> WindowsVista';
        } else if (preg_match('/nt 6.1/i', $agent)) {
            $os = '<i class="mdi mdi-windows"></i> Windows7';
        } else if (preg_match('/nt 6.2/i', $agent)) {
            $os = '<i class="mdi mdi-windows"></i> Windows8';
        } else if(preg_match('/nt 6.3/i', $agent)) {
            $os = '<i class="mdi mdi-windows"></i> Windows8.1';
        } else if(preg_match('/nt 5.1/i', $agent)) {
            $os = '<i class="mdi mdi-windows-classic"></i> WindowsXP';
        } else if (preg_match('/nt 10.0/i', $agent)) {
            $os = '<i class="mdi mdi-windows"></i> Windows10';
        } else{
            $os = '<i class="mdi mdi-windows"></i> Windows';
        }
    } else if (preg_match('/android/i', $agent)) {
if (preg_match('/android 10/i', $agent)) {
        $os = '<i class="mdi mdi-android"></i> 安卓 10';
    }
if (preg_match('/android 9/i', $agent)) {
        $os = '<i class="mdi mdi-android"></i> 安卓派';
    }
else if (preg_match('/android 8/i', $agent)) {
        $os = '<i class="mdi mdi-android"></i> 安卓奥利奥';
    }
else if (preg_match('/android 7/i', $agent)) {
        $os = '<i class="mdi mdi-android"></i> 安卓牛轧糖';
    }
else if (preg_match('/android 6/i', $agent)) {
        $os = '<i class="mdi mdi-android"></i> 安卓棉花糖';
    }
else if (preg_match('/android 5/i', $agent)) {
        $os = '<i class="mdi mdi-android"></i> 安卓棒棒糖';
    }
else{
        $os = '<i class="mdi mdi-android"></i> 安卓';
}
    }
 else if (preg_match('/ubuntu/i', $agent)) {
        $os = '<i class="mdi mdi-ubuntu"></i> 乌班图';
    } else if (preg_match('/linux/i', $agent)) {
        $os = '<i class="mdi mdi-linux"></i> Linux';
    } else if (preg_match('/iPhone/i', $agent)) {
        $os = '<i class="mdi mdi-cellphone-iphone"></i> Ios';
    } else if (preg_match('/iPad/i', $agent)) {
        $os = '<i class="mdi mdi-tablet-ipad"></i> IpadOS';
    } else if (preg_match('/mac/i', $agent)) {
        $os = '<i class="mdi mdi-desktop-mac"></i> MacOS';
    }else if (preg_match('/cros/i', $agent)) {
        $os = '<i class="mdi mdi-google-chrome"></i> ChromeOS';
    }else if (preg_match('/BlackBerry/i', $agent)) {
        $os = '<i class="mdi mdi-blackberry"></i> 黑莓';
    }else {
 return false;
    }
   return $os;
}

function coryright()
{
$a='';$b='';
if (Helper::options()->footerwen){$a = Helper::options()->footerwen;}if (Helper::options()->footerwen2){$b = Helper::options()->footerwen2;}
$c=date('Y').' © <a target="_blank" href="http://typecho.org/" rel="external nofollow">Typecho</a> Theme <a target="_blank" href="https://cmsboy.cn/archives/end-1.html" rel="external nofollow">End</a> ';
if (!empty(Helper::options()->tools) && in_array('banquanzaijian', Helper::options()->tools)){$c='';}
echo $c.$a.'</div><div class="col-md-6"><div class="text-md-right footer-links d-none d-md-block">'.$b;
}
function theNext($widget, $default = NULL)
{
$db = Typecho_Db::get();
if (!empty($widget->widget('Widget_Options')->tools) && in_array('CategoryNext', $widget->widget('Widget_Options')->tools)){
@$mid=intval($widget->categories[0]['mid']);
$sql = $db->select()->from('table.contents')->join('table.relationships', 'table.contents.cid = table.relationships.cid')
->where('table.relationships.mid = ?', $mid)
->where('table.contents.created > ?', $widget->created)
->where('table.contents.status = ?', 'publish')
->where('table.contents.type = ?', $widget->type)
->where('table.contents.password IS NULL')
->order('table.contents.created', Typecho_Db::SORT_ASC)
->limit(1);
}else{
$sql = $db->select()->from('table.contents')
->where('table.contents.created > ?', $widget->created)
->where('table.contents.status = ?', 'publish')
->where('table.contents.type = ?', $widget->type)
->where('table.contents.password IS NULL')
->order('table.contents.created', Typecho_Db::SORT_ASC)
->limit(1);
}
$content = $db->fetchRow($sql);
if ($content) {
$content = $widget->filter($content);
$link = '<a href="' . $content['permalink'] . '" class="btn btn-primary float-right">下一篇<i class="mdi mdi-chevron-right"></i></a>';
echo $link;
} else {
$link = '<buttom class="btn btn-outline-primary float-right">'.$default.'</buttom>';
echo $link;
}
}
function thePrev($widget, $default = NULL)
{
$db = Typecho_Db::get();
if (!empty($widget->widget('Widget_Options')->tools) && in_array('CategoryNext', $widget->widget('Widget_Options')->tools)){
@$mid=intval($widget->categories[0]['mid']);
$sql = $db->select()->from('table.contents')->join('table.relationships', 'table.contents.cid = table.relationships.cid')
->where('table.relationships.mid = ?', $mid)
->where('table.contents.created < ?', $widget->created)
->where('table.contents.status = ?', 'publish')
->where('table.contents.type = ?', $widget->type)
->where('table.contents.password IS NULL')
->order('table.contents.created', Typecho_Db::SORT_DESC)
->limit(1);
}else{
$sql = $db->select()->from('table.contents')
->where('table.contents.created < ?', $widget->created)
->where('table.contents.status = ?', 'publish')
->where('table.contents.type = ?', $widget->type)
->where('table.contents.password IS NULL')
->order('table.contents.created', Typecho_Db::SORT_DESC)
->limit(1);
}
$content = $db->fetchRow($sql);
if ($content) {
$content = $widget->filter($content);
$link = '<a href="' . $content['permalink'] . '" class="btn btn-primary"><i class="mdi mdi-chevron-left"></i>上一篇</a>';
echo $link;
} else {
$link = '<buttom class="btn btn-outline-primary">'.$default.'</buttom>';
echo $link;
}
}

class Widget_Post_hot extends Widget_Abstract_Contents
{
    public function __construct($request, $response, $params = NULL)
    {
        parent::__construct($request, $response, $params);
        $this->parameter->setDefault(array('pageSize' => $this->options->commentsListSize, 'parentId' => 0, 'ignoreAuthor' => false));
    }
    public function execute()
    {
        $select  = $this->select()->from('table.contents')
->where("table.contents.password IS NULL OR table.contents.password = ''")
->where('table.contents.status = ?','publish')
->where('table.contents.created <= ?', time())
->where('table.contents.type = ?', 'post')
->limit($this->parameter->pageSize)
->order('table.contents.views', Typecho_Db::SORT_DESC);
 $this->db->fetchAll($select, array($this, 'push'));
    }
}




Typecho_Plugin::factory('Widget_Feedback')->comment = array('plgl', 'one');
Typecho_Plugin::factory('Widget_Abstract_Contents')->excerptEx = array('plgl','two');
Typecho_Plugin::factory('Widget_Abstract_Contents')->contentEx = array('plgl','two');
Typecho_Plugin::factory('admin/write-post.php')->bottom = array('plgl', 'san');
Typecho_Plugin::factory('admin/write-page.php')->bottom = array('plgl', 'san');
class plgl {
public static function one($comment, $post)
    {
$options = Helper::options();
$opt = "none";
$errorx ="";

if (!empty($options->tools) && in_array('qzlogin', $options->tools)){
$user = Typecho_Widget::widget('Widget_User');
/*通过判断id来判断用户是否登录*/
if(!$user->uid > 0){ 
	$errorx = "抱歉，您必须登录后才能评论！";
	$opt = 'abandon';
}}
  
  
if(preg_match("/<a(.*?)href=\"javascript:(.*?)>(.*?)<\/a>/u",$comment['text'])==1){
	$errorx = "评论中超链接里请不要使用脚本！";
	$opt = 'abandon';
}
if(ctype_space($comment['text'])){
	$errorx = "请不要使用空格评论！";
	$opt = 'abandon';
}
  
if ($opt == "none" && $options->opt_nocn != "none") {
if (preg_match("/[\x{4e00}-\x{9fa5}]/u", $comment['text']) == 0) {
	$errorx = "评论内容请不少于一个中文汉字";
	$opt = $options->opt_nocn;
}
}

//屏蔽网址处理
        if(!empty($options->words_url)){
            if ($opt == "none" && $options->opt_url != "none") {
                if (check_in($options->words_url, $comment['url'])) {
                    $errorx = "评论发布者的网址被管理员屏蔽";
                    $opt = $options->opt_url;
                }			
            }
        } 

//检查敏感词汇
if(!empty($options->words_chk)){
	if ($opt == "none" && $options->opt_chk != "none") {
		if (check_in($options->words_chk, $comment['text'])) {
			$errorx = "评论内容中包含敏感词汇";
			$opt = $options->opt_chk;
		}
	}
}

//屏蔽邮箱处理
if(!empty($options->words_mail)){
	if ($opt == "none" && $options->opt_mail != "none") {
		if (check_in($options->words_mail, $comment['mail'])) {
			$errorx = "评论发布者的邮箱地址被管理员屏蔽";
			$opt = $options->opt_mail;
		}			
	} 
}
//屏蔽昵称关键词处理
if(!empty($options->words_au)){
	if ($opt == "none" && $options->opt_au != "none") {
		if (check_in($options->words_au, $comment['author'])) {
			$errorx = "对不起，昵称的部分字符已经被管理员屏蔽，请更换";
			$opt = $options->opt_au;
		}			
	}
}

if ($opt == "abandon") {
Typecho_Cookie::set('__typecho_remember_text', $comment['text']);
throw new Typecho_Widget_Exception($errorx);
		}
else if ($opt == "spam") {
$comment['status'] = 'spam';
		}
else if ($opt == "waiting") {
$comment['status'] = 'waiting';
		}
Typecho_Cookie::delete('__typecho_remember_text');
        return $comment;
}
public static function two($con,$obj,$text)
    {
      $text = empty($text)?$con:$text;
$db = Typecho_Db::get();
$user = Typecho_Widget::widget('Widget_User');
/*通过判断id来判断用户是否登录*/
if($user->uid > 0){
$sql = $db->select()->from('table.comments')
    ->where('cid = ?',$obj->cid)
    ->where('authorId = ?', $user->uid)
    ->where('status = ?', 'approved')
    ->limit(1);
}else{
$sql = $db->select()->from('table.comments')
    ->where('cid = ?',$obj->cid)
    ->where('mail = ?', $obj->remember('mail',true))
    ->where('status = ?', 'approved')
    ->limit(1);
}
$result = $db->fetchAll($sql);
if(!$obj->is('single'))
{
if($result || $user->uid==$obj->authorId){
$text= preg_replace("/\[hide\](.*?)\[\/hide\]/sm",'<div class="reply2view-ok"><fieldset><legend>回复可见内容</legend>$1</fieldset></div>',$text);
}else{
$text = preg_replace("/\[hide\](.*?)\[\/hide\]/sm",'回复可见内容',$text);
}}
return $text;
}
   public static function san()
    {
    ?>
<style>.wmd-button-row{height:auto;}.OwO{position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;}.OwO.OwO-open .OwO-body{display:block}.OwO.OwO-up .OwO-body{top:inherit;bottom:21px;border-radius:4px 4px 4px 0}.OwO.OwO-up .OwO-body .OwO-bar .OwO-packages li:nth-child(1){border-radius:0}.OwO.OwO-up.OwO-open .OwO-logo{border:1px solid #ddd;border-radius:0 0 4px 4px;border-top:none}.OwO .OwO-logo{position:relative;display:inline-block;cursor:pointer;box-sizing:border-box;z-index:2;}.OwO .OwO-logo:hover span{display:inline-block;-webkit-animation:a 5s infinite ease-in-out;animation:a 5s infinite ease-in-out}.OwO .OwO-body{display:none;position:relative;background:#fff;}.OwO .OwO-body .OwO-items{-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;display:none;padding:10px;margin:0;overflow-y:scroll;font-size:0}.OwO .OwO-body .OwO-items .OwO-item{list-style-type:none;background:#f7f7f7;padding:5px 10px;border-radius:5px;display:inline-block;font-size:12px;line-height:14px;margin:0 10px 12px 0;cursor:pointer;-webkit-transition:.3s;transition:.3s}.OwO .OwO-body .OwO-items .OwO-item:hover{background:#eee;box-shadow:0 2px 2px 0 rgba(0,0,0,.14),0 3px 1px -2px rgba(0,0,0,.2),0 1px 5px 0 rgba(0,0,0,.12);-webkit-animation:a 5s infinite ease-in-out;animation:a 5s infinite ease-in-out}.OwO .OwO-body .OwO-items-emoji .OwO-item{font-size:20px;line-height:19px}.OwO .OwO-body .OwO-items-image .OwO-item{max-width:calc(25% - 10px);box-sizing:border-box}.OwO .OwO-body .OwO-items-image .OwO-item img{max-width:100%}.OwO .OwO-body .OwO-items-show{display:block}.OwO .OwO-body .OwO-bar{width:100%;height:30px;border-top:1px solid #ddd;background:#fff;border-radius:0 0 4px 4px;color:#444}.OwO .OwO-body .OwO-bar .OwO-packages{margin:0;padding:0;font-size:0}.OwO .OwO-body .OwO-bar .OwO-packages li{list-style-type:none;display:inline-block;line-height:30px;font-size:14px;padding:0 10px;cursor:pointer;margin:0}.OwO .OwO-body .OwO-bar .OwO-packages li:nth-child(1){border-radius:0 0 0 3px}.OwO .OwO-body .OwO-bar .OwO-packages li:hover{background:#eee}.OwO .OwO-body .OwO-bar .OwO-packages .OwO-package-active{background:#eee;-webkit-transition:.3s;transition:.3s}@-webkit-keyframes a{2%{-webkit-transform:translateY(1.5px) rotate(1.5deg);transform:translateY(1.5px) rotate(1.5deg)}4%{-webkit-transform:translateY(-1.5px) rotate(-.5deg);transform:translateY(-1.5px) rotate(-.5deg)}6%{-webkit-transform:translateY(1.5px) rotate(-1.5deg);transform:translateY(1.5px) rotate(-1.5deg)}8%{-webkit-transform:translateY(-1.5px) rotate(-1.5deg);transform:translateY(-1.5px) rotate(-1.5deg)}10%{-webkit-transform:translateY(2.5px) rotate(1.5deg);transform:translateY(2.5px) rotate(1.5deg)}12%{-webkit-transform:translateY(-.5px) rotate(1.5deg);transform:translateY(-.5px) rotate(1.5deg)}14%{-webkit-transform:translateY(-1.5px) rotate(1.5deg);transform:translateY(-1.5px) rotate(1.5deg)}16%{-webkit-transform:translateY(-.5px) rotate(-1.5deg);transform:translateY(-.5px) rotate(-1.5deg)}18%{-webkit-transform:translateY(.5px) rotate(-1.5deg);transform:translateY(.5px) rotate(-1.5deg)}20%{-webkit-transform:translateY(-1.5px) rotate(2.5deg);transform:translateY(-1.5px) rotate(2.5deg)}22%{-webkit-transform:translateY(.5px) rotate(-1.5deg);transform:translateY(.5px) rotate(-1.5deg)}24%{-webkit-transform:translateY(1.5px) rotate(1.5deg);transform:translateY(1.5px) rotate(1.5deg)}26%{-webkit-transform:translateY(.5px) rotate(.5deg);transform:translateY(.5px) rotate(.5deg)}28%{-webkit-transform:translateY(.5px) rotate(1.5deg);transform:translateY(.5px) rotate(1.5deg)}30%{-webkit-transform:translateY(-.5px) rotate(2.5deg);transform:translateY(-.5px) rotate(2.5deg)}32%,34%{-webkit-transform:translateY(1.5px) rotate(-.5deg);transform:translateY(1.5px) rotate(-.5deg)}36%{-webkit-transform:translateY(-1.5px) rotate(2.5deg);transform:translateY(-1.5px) rotate(2.5deg)}38%{-webkit-transform:translateY(1.5px) rotate(-1.5deg);transform:translateY(1.5px) rotate(-1.5deg)}40%{-webkit-transform:translateY(-.5px) rotate(2.5deg);transform:translateY(-.5px) rotate(2.5deg)}42%{-webkit-transform:translateY(2.5px) rotate(-1.5deg);transform:translateY(2.5px) rotate(-1.5deg)}44%{-webkit-transform:translateY(1.5px) rotate(.5deg);transform:translateY(1.5px) rotate(.5deg)}46%{-webkit-transform:translateY(-1.5px) rotate(2.5deg);transform:translateY(-1.5px) rotate(2.5deg)}48%{-webkit-transform:translateY(-.5px) rotate(.5deg);transform:translateY(-.5px) rotate(.5deg)}50%{-webkit-transform:translateY(.5px) rotate(.5deg);transform:translateY(.5px) rotate(.5deg)}52%{-webkit-transform:translateY(2.5px) rotate(2.5deg);transform:translateY(2.5px) rotate(2.5deg)}54%{-webkit-transform:translateY(-1.5px) rotate(1.5deg);transform:translateY(-1.5px) rotate(1.5deg)}56%{-webkit-transform:translateY(2.5px) rotate(2.5deg);transform:translateY(2.5px) rotate(2.5deg)}58%{-webkit-transform:translateY(.5px) rotate(2.5deg);transform:translateY(.5px) rotate(2.5deg)}60%{-webkit-transform:translateY(2.5px) rotate(2.5deg);transform:translateY(2.5px) rotate(2.5deg)}62%{-webkit-transform:translateY(-.5px) rotate(2.5deg);transform:translateY(-.5px) rotate(2.5deg)}64%{-webkit-transform:translateY(-.5px) rotate(1.5deg);transform:translateY(-.5px) rotate(1.5deg)}66%{-webkit-transform:translateY(1.5px) rotate(-.5deg);transform:translateY(1.5px) rotate(-.5deg)}68%{-webkit-transform:translateY(-1.5px) rotate(-.5deg);transform:translateY(-1.5px) rotate(-.5deg)}70%{-webkit-transform:translateY(1.5px) rotate(.5deg);transform:translateY(1.5px) rotate(.5deg)}72%{-webkit-transform:translateY(2.5px) rotate(1.5deg);transform:translateY(2.5px) rotate(1.5deg)}74%{-webkit-transform:translateY(-.5px) rotate(.5deg);transform:translateY(-.5px) rotate(.5deg)}76%{-webkit-transform:translateY(-.5px) rotate(2.5deg);transform:translateY(-.5px) rotate(2.5deg)}78%{-webkit-transform:translateY(-.5px) rotate(1.5deg);transform:translateY(-.5px) rotate(1.5deg)}80%{-webkit-transform:translateY(1.5px) rotate(1.5deg);transform:translateY(1.5px) rotate(1.5deg)}82%{-webkit-transform:translateY(-.5px) rotate(.5deg);transform:translateY(-.5px) rotate(.5deg)}84%{-webkit-transform:translateY(1.5px) rotate(2.5deg);transform:translateY(1.5px) rotate(2.5deg)}86%{-webkit-transform:translateY(-1.5px) rotate(-1.5deg);transform:translateY(-1.5px) rotate(-1.5deg)}88%{-webkit-transform:translateY(-.5px) rotate(2.5deg);transform:translateY(-.5px) rotate(2.5deg)}90%{-webkit-transform:translateY(2.5px) rotate(-.5deg);transform:translateY(2.5px) rotate(-.5deg)}92%{-webkit-transform:translateY(.5px) rotate(-.5deg);transform:translateY(.5px) rotate(-.5deg)}94%{-webkit-transform:translateY(2.5px) rotate(.5deg);transform:translateY(2.5px) rotate(.5deg)}96%{-webkit-transform:translateY(-.5px) rotate(1.5deg);transform:translateY(-.5px) rotate(1.5deg)}98%{-webkit-transform:translateY(-1.5px) rotate(-.5deg);transform:translateY(-1.5px) rotate(-.5deg)}0%,to{-webkit-transform:translate(0) rotate(0deg);transform:translate(0) rotate(0deg)}}@keyframes a{2%{-webkit-transform:translateY(1.5px) rotate(1.5deg);transform:translateY(1.5px) rotate(1.5deg)}4%{-webkit-transform:translateY(-1.5px) rotate(-.5deg);transform:translateY(-1.5px) rotate(-.5deg)}6%{-webkit-transform:translateY(1.5px) rotate(-1.5deg);transform:translateY(1.5px) rotate(-1.5deg)}8%{-webkit-transform:translateY(-1.5px) rotate(-1.5deg);transform:translateY(-1.5px) rotate(-1.5deg)}10%{-webkit-transform:translateY(2.5px) rotate(1.5deg);transform:translateY(2.5px) rotate(1.5deg)}12%{-webkit-transform:translateY(-.5px) rotate(1.5deg);transform:translateY(-.5px) rotate(1.5deg)}14%{-webkit-transform:translateY(-1.5px) rotate(1.5deg);transform:translateY(-1.5px) rotate(1.5deg)}16%{-webkit-transform:translateY(-.5px) rotate(-1.5deg);transform:translateY(-.5px) rotate(-1.5deg)}18%{-webkit-transform:translateY(.5px) rotate(-1.5deg);transform:translateY(.5px) rotate(-1.5deg)}20%{-webkit-transform:translateY(-1.5px) rotate(2.5deg);transform:translateY(-1.5px) rotate(2.5deg)}22%{-webkit-transform:translateY(.5px) rotate(-1.5deg);transform:translateY(.5px) rotate(-1.5deg)}24%{-webkit-transform:translateY(1.5px) rotate(1.5deg);transform:translateY(1.5px) rotate(1.5deg)}26%{-webkit-transform:translateY(.5px) rotate(.5deg);transform:translateY(.5px) rotate(.5deg)}28%{-webkit-transform:translateY(.5px) rotate(1.5deg);transform:translateY(.5px) rotate(1.5deg)}30%{-webkit-transform:translateY(-.5px) rotate(2.5deg);transform:translateY(-.5px) rotate(2.5deg)}32%,34%{-webkit-transform:translateY(1.5px) rotate(-.5deg);transform:translateY(1.5px) rotate(-.5deg)}36%{-webkit-transform:translateY(-1.5px) rotate(2.5deg);transform:translateY(-1.5px) rotate(2.5deg)}38%{-webkit-transform:translateY(1.5px) rotate(-1.5deg);transform:translateY(1.5px) rotate(-1.5deg)}40%{-webkit-transform:translateY(-.5px) rotate(2.5deg);transform:translateY(-.5px) rotate(2.5deg)}42%{-webkit-transform:translateY(2.5px) rotate(-1.5deg);transform:translateY(2.5px) rotate(-1.5deg)}44%{-webkit-transform:translateY(1.5px) rotate(.5deg);transform:translateY(1.5px) rotate(.5deg)}46%{-webkit-transform:translateY(-1.5px) rotate(2.5deg);transform:translateY(-1.5px) rotate(2.5deg)}48%{-webkit-transform:translateY(-.5px) rotate(.5deg);transform:translateY(-.5px) rotate(.5deg)}50%{-webkit-transform:translateY(.5px) rotate(.5deg);transform:translateY(.5px) rotate(.5deg)}52%{-webkit-transform:translateY(2.5px) rotate(2.5deg);transform:translateY(2.5px) rotate(2.5deg)}54%{-webkit-transform:translateY(-1.5px) rotate(1.5deg);transform:translateY(-1.5px) rotate(1.5deg)}56%{-webkit-transform:translateY(2.5px) rotate(2.5deg);transform:translateY(2.5px) rotate(2.5deg)}58%{-webkit-transform:translateY(.5px) rotate(2.5deg);transform:translateY(.5px) rotate(2.5deg)}60%{-webkit-transform:translateY(2.5px) rotate(2.5deg);transform:translateY(2.5px) rotate(2.5deg)}62%{-webkit-transform:translateY(-.5px) rotate(2.5deg);transform:translateY(-.5px) rotate(2.5deg)}64%{-webkit-transform:translateY(-.5px) rotate(1.5deg);transform:translateY(-.5px) rotate(1.5deg)}66%{-webkit-transform:translateY(1.5px) rotate(-.5deg);transform:translateY(1.5px) rotate(-.5deg)}68%{-webkit-transform:translateY(-1.5px) rotate(-.5deg);transform:translateY(-1.5px) rotate(-.5deg)}70%{-webkit-transform:translateY(1.5px) rotate(.5deg);transform:translateY(1.5px) rotate(.5deg)}72%{-webkit-transform:translateY(2.5px) rotate(1.5deg);transform:translateY(2.5px) rotate(1.5deg)}74%{-webkit-transform:translateY(-.5px) rotate(.5deg);transform:translateY(-.5px) rotate(.5deg)}76%{-webkit-transform:translateY(-.5px) rotate(2.5deg);transform:translateY(-.5px) rotate(2.5deg)}78%{-webkit-transform:translateY(-.5px) rotate(1.5deg);transform:translateY(-.5px) rotate(1.5deg)}80%{-webkit-transform:translateY(1.5px) rotate(1.5deg);transform:translateY(1.5px) rotate(1.5deg)}82%{-webkit-transform:translateY(-.5px) rotate(.5deg);transform:translateY(-.5px) rotate(.5deg)}84%{-webkit-transform:translateY(1.5px) rotate(2.5deg);transform:translateY(1.5px) rotate(2.5deg)}86%{-webkit-transform:translateY(-1.5px) rotate(-1.5deg);transform:translateY(-1.5px) rotate(-1.5deg)}88%{-webkit-transform:translateY(-.5px) rotate(2.5deg);transform:translateY(-.5px) rotate(2.5deg)}90%{-webkit-transform:translateY(2.5px) rotate(-.5deg);transform:translateY(2.5px) rotate(-.5deg)}92%{-webkit-transform:translateY(.5px) rotate(-.5deg);transform:translateY(.5px) rotate(-.5deg)}94%{-webkit-transform:translateY(2.5px) rotate(.5deg);transform:translateY(2.5px) rotate(.5deg)}96%{-webkit-transform:translateY(-.5px) rotate(1.5deg);transform:translateY(-.5px) rotate(1.5deg)}98%{-webkit-transform:translateY(-1.5px) rotate(-.5deg);transform:translateY(-1.5px) rotate(-.5deg)}0%,to{-webkit-transform:translate(0) rotate(0deg);transform:translate(0) rotate(0deg)}}.OwO-jio{display:none;}img.biaoqing{max-height:30px;}.OwO span{background:none!important;width:unset!important;height:unset!important}.OwO .OwO-body .OwO-items{-webkit-overflow-scrolling:touch;overflow-x:hidden;}.OwO .OwO-body .OwO-items-image .OwO-item{max-width:-moz-calc(20% - 10px);max-width:-webkit-calc(20% - 10px);max-width:calc(20% - 10px)}@media screen and (max-width:767px){.comment-info-input{flex-direction:column;}.comment-info-input input{max-width:100%;margin-top:5px}#comments .comment-author .avatar{width:2.5rem;height:2.5rem;}}@media screen and (max-width:760px){.OwO .OwO-body .OwO-items-image .OwO-item{max-width:-moz-calc(25% - 10px);max-width:-webkit-calc(25% - 10px);max-width:calc(25% - 10px)}}
</style>
<script src="<?php echo theurl; ?>assets/OwO.min.js?201908161808"></script>
<script> 
          $(document).ready(function(){
          	$('#wmd-button-row').append('<li class="wmd-button" id="wmd-jrotty-button" title="回复可见"><span style="background: none;"><img style="height: 20px;width: 20px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQEAYAAABPYyMiAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAAZiS0dEAAAAAAAA+UO7fwAAAAlwSFlzAAAASAAAAEgARslrPgAAAoFJREFUSMftlE1IVHEUxX/3jTWbKY1ZZWiB4cKNm2qCXAgRoQsp6c1TmI2Ii1mkoTMSbVqMgTWMxYAu3LxFH/reiBAtNEoIG5cRJSKzyEkiW2kZs7I3c1v0nQwEIbXwbA/33nPPPf8/7OJ/x1RoKjRxMxTaqf5SjnBd13Vdnw9AU9PTALwtFEiTliN1dfTSq+2HDwPgFYsAPM/nAeT87GxxpjhTnLHtTrvT7rTX1srNMcoRWq3VWh2JaEpTcOOGXJWr3PT76aVXo8eOSb/0c2J5GYCHi4tMMMGH48cBVIeGfC2+FuNULpdJZpKT77q6/tgBZ91Zd9ZjMZmTOR4nkwC839xUW23ut7XJiqzISjRKgkQp/eoVgLE5MlJqLDWWGmtqjBfGC3mazQKwLxD4sREqDA6GrbAVtr72/dmBjGZ0QpubjaARpOr69V9UHaislJzkJNfdTYIEiUgEQCK1tQD6cXVV85rX/MYGgHbdu7dtU0ssvTA87Dqu4zpnzmwToK66PtfztF3bOVcqlU2NomggYKSMVOnK6CgAUcepGK4YNrKxmNySW5IsXy9n5Wwp9oP/LuCLNdms1Es9T/r6thW+lte6HA4jCNLQ4P/k/xS4vbhomqYZ3urpYYstAnv36iW9RE1PzzbdjjoydfmyWWVWdbyZmyubge9ZyDgZJxMOi4qyPj7+7RRMMskdz6ODDvwLCyRJyqrnESdOPJ2WMRnTl6dPa1CDLF28KCflpI51d5txM95x0LZ/n1P2FVimZVqm63qPvEfFZ0ePAogMDGBhYczPA9Bw6JAsyZI+qK9HUb3b1+dr9bXu2X/tmhSkQG0qhYsrU01N/Cvs9Ee2i7/GZ0fjDN8XfZq1AAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTAxVDIyOjIxOjU3KzA4OjAw0/e32gAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0wMVQyMjoyMTo1NyswODowMKKqD2YAAABSdEVYdHN2ZzpiYXNlLXVyaQBmaWxlOi8vL2hvbWUvYWRtaW4vaWNvbi1mb250L3RtcC9pY29uXzZ5N3JpZm1kb3BqL3lpbmNhbmdidWtlamlhbi5zdmd9LUM+AAAAAElFTkSuQmCC"/></span></li><li class="wmd-button"><a href="javascript: void(0);"class="OwO-logo" rel="external nofollow">表情</a></li><div class="OwO"></div>');
				if($('#wmd-button-row').length !== 0){
					$('#wmd-jrotty-button').click(function(){
						var rs = "[hide]回复可见内容[/hide]";
						var myField = $('#text')[0];
                insertAtCursor(myField,rs);
					})
				}
/*评论表情配置*/
if($(".OwO").length > 0) {
var OwO_demo = new OwO({
            container: document.getElementsByClassName('OwO')[0],
            target: document.getElementById('text'),
            api: '<?php echo theurl; ?>assets/OwO.json',
            position: 'down',
            width: '100%',
            maxHeight: '150px'
});
}
        function insertAtCursor(myField, myValue) {
            //IE 浏览器  
            if (document.selection) {  
                myField.focus();  
                sel = document.selection.createRange();
                sel.text = myValue;  
                sel.select();  
            }
             //FireFox、Chrome等  
            else if (myField.selectionStart || myField.selectionStart == '0') {  
                var startPos = myField.selectionStart;  
                var endPos = myField.selectionEnd; 
                // 保存滚动条  
              var restoreTop = myField.scrollTop;  
                myField.value = myField.value.substring(0, startPos) + myValue + myField.value.substring(endPos, myField.value.length);  
                if (restoreTop > 0) {myField.scrollTop = restoreTop;}  
                myField.focus();  
                myField.selectionStart = startPos + myValue.length;  
                myField.selectionEnd = startPos + myValue.length;
            } else {  
                myField.value += myValue;
                myField.focus();
            }  
        }
			});
</script>
<script> $(document).ready(function(){     $('#custom-field-expand').before('<div id="tdk" style="float: right;cursor: pointer;"><a>TDK</a></div>');
 function attachDeleteEvent (el) {
        $('button.btn-xs', el).click(function () {
            if (confirm('确认要删除此字段吗?')) {
                $(this).parents('tr').fadeOut(function () {
                    $(this).remove();
                });

                $(this).parents('form').trigger('field');
            }
        });
    }                     
$('#tdk').click(function () {                                          
 // 展开字段
        if ($('#custom-field').hasClass('fold')) {
        $('#custom-field').removeClass('fold');
         var btn = $('i', '#custom-field-expand');
        if (btn.hasClass('i-caret-right')) {
            btn.removeClass('i-caret-right').addClass('i-caret-down');
        }
}

 //隐藏typecho的默认字段
    $("#custom-field").find("input[type='text']").each(function () {
                    if ($(this).val() == "") {
                    $(this).parent().parent().hide();
                    }
});
//插入预设字段    
        var html = '<tr><td><label class="text-s w-100">文章描述</label></td>'
                + '<td><select name="fieldTypes[]" id="">'
                + '<option value="str">字符</option>'
                + '</select></td>'
                + '<td><textarea name="fields[d]" placeholder="文章描述" class="text-s w-100" rows="1"></textarea><p class="description">此处输入文章描述，用于展示给搜索引擎</p></td>'
                + '<td><button type="button" class="btn btn-xs">删除</button></td></tr>'
                + '<tr><td><label class="text-s w-100">文章关键词</label></td>'
                + '<td><select name="fieldTypes[]" id="">'
                + '<option value="str">字符</option>'
                + '</select></td>'
                + '<td><textarea name="fields[k]" placeholder="文章关键词" class="text-s w-100" rows="4"></textarea><p class="description">此处输入文章关键词，用于展示给搜索引擎</p></td>'
                + '<td><button type="button" class="btn btn-xs">删除</button></td></tr>',
            el = $(html).hide().appendTo('#custom-field table tbody').fadeIn();
            $(':input', el).bind('input change', function () {
                $(this).parents('form').trigger('field');
            });
        attachDeleteEvent(el);
    });
  });</script>
<?php
    }



}

?>