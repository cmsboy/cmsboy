<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 $this->need('sidebar.php');
$lie= Helper::options()->freestyle ? explode(',', strtr(Helper::options()->freestyle, ' ', ',')) : array("3","6","12");
 ?>
<div class="container-fluid mb-3">

<div class="row">
<div class="col-12">
<div class="page-title-box">
<div class="page-title-right">

</div>
<h4 class="page-title">
<?php if ($this->is('search')) : ?>
<?php 

$keywords = $this->_keywords;
$cat=intval($this->request->cat);
if($cat>0){
echo "分类“".cname(intval($cat))."”包含“".$keywords."”的文章如下";}else{
echo "包含关键字“".$keywords."”的文章如下";
$can='?cat='.$cat;
}
?>
<?php
global $can;

if($cat>0){$can='?cat='.$cat;}else{$can="";}
/**
 * Typecho Blog Platform
 *
 * @copyright  Copyright (c) 2008 Typecho team (http://www.typecho.org)
 * @license    GNU General Public License 2.0
 * @version    $Id$
 */
/**
 * 盒状分页样式
 *
 * @author qining
 * @category typecho
 * @package Widget
 * @copyright Copyright (c) 2008 Typecho team (http://www.typecho.org)
 * @license GNU General Public License 2.0
 */
class Typecho_Widget_Helper_PageNavigator_Box extends Typecho_Widget_Helper_PageNavigator
{
    /**
     * 输出盒装样式分页栏
     *
     * @access public
     * @param string $prevWord 上一页文字
     * @param string $nextWord 下一页文字
     * @param int $splitPage 分割范围
     * @param string $splitWord 分割字符
     * @param string $currentClass 当前激活元素class
     * @return void
     */
    public function render($prevWord = 'PREV', $nextWord = 'NEXT', $splitPage = 3, $splitWord = '...', array $template = array())
    { 
        if ($this->_total < 1) {
            return;
        }
        $default = array(
            'aClass'  =>  '',
            'itemTag'       =>  'li',
            'textTag'       =>  'span',
            'textClass'       =>  '',
            'currentClass'  =>  'current',
            'prevClass'     =>  'prev',
            'nextClass'     =>  'next'
        );
        $template = array_merge($default, $template);
        extract($template);
        // 定义item
        $itemBegin = empty($itemTag) ? '' : ('<' . $itemTag . '>');
        $itemCurrentBegin = empty($itemTag) ? '' : ('<' . $itemTag 
            . (empty($currentClass) ? '' : ' class="' . $currentClass . '"') . '>');
        $itemPrevBegin = empty($itemTag) ? '' : ('<' . $itemTag 
            . (empty($prevClass) ? '' : ' class="' . $prevClass . '"') . '>');
        $itemNextBegin = empty($itemTag) ? '' : ('<' . $itemTag 
            . (empty($nextClass) ? '' : ' class="' . $nextClass . '"') . '>');
        $itemEnd = empty($itemTag) ? '' : ('</' . $itemTag . '>');
        $textBegin = empty($textTag) ? '' : ('<' . $textTag 
            . (empty($textClass) ? '' : ' class="' . $textClass . '"') . '>');
        $textEnd = empty($textTag) ? '' : ('</' . $textTag . '>');

        $linkBegin = '<a href="%s" '. (empty($aClass) ? '' : ' class="' . $aClass . '"') . '>';
        $linkCurrentBegin = empty($itemTag) ? ('<a href="%s"'
            . (empty($currentClass) ? '' : ' class="' . $currentClass . '"') . '>')
            : $linkBegin;
        $linkPrevBegin = empty($itemTag) ? ('<a href="%s"'
            . (empty($prevClass) ? '' : ' class="' . $prevClass . '"') . '>')
            : $linkBegin;
        $linkNextBegin = empty($itemTag) ? ('<a href="%s"'
            . (empty($nextClass) ? '' : ' class="' . $nextClass . '"') . '>')
            : $linkBegin;
        $linkEnd = '</a>';
        $from = max(1, $this->_currentPage - $splitPage);
        $to = min($this->_totalPage, $this->_currentPage + $splitPage);
        //输出上一页
        if ($this->_currentPage > 1) {
            echo $itemPrevBegin . sprintf($linkPrevBegin,
                str_replace($this->_pageHolder, $this->_currentPage - 1, $this->_pageTemplate) . $this->_anchor. $GLOBALS['can'])
                . $prevWord . $linkEnd . $itemEnd;
        }
        //输出第一页
        if ($from > 1) {
            echo $itemBegin . sprintf($linkBegin, str_replace($this->_pageHolder, 1, $this->_pageTemplate) . $this->_anchor. $GLOBALS['can'])
                . '1' . $linkEnd . $itemEnd;
            if ($from > 2) {
                //输出省略号
                echo $itemBegin . $textBegin . $splitWord . $textEnd . $itemEnd;
            }
        }
        //输出中间页
        for ($i = $from; $i <= $to; $i ++) {
            $current = ($i == $this->_currentPage);
            
            echo ($current ? $itemCurrentBegin : $itemBegin) . sprintf(($current ? $linkCurrentBegin : $linkBegin),
                str_replace($this->_pageHolder, $i, $this->_pageTemplate) . $this->_anchor. $GLOBALS['can'])
                . $i . $linkEnd . $itemEnd;
        }
        //输出最后页
        if ($to < $this->_totalPage) {
            if ($to < $this->_totalPage - 1) {
                echo $itemBegin . $textBegin . $splitWord . $textEnd . $itemEnd;
            }
            
            echo $itemBegin . sprintf($linkBegin, str_replace($this->_pageHolder, $this->_totalPage, $this->_pageTemplate) . $this->_anchor. $GLOBALS['can'])
                . $this->_totalPage . $linkEnd . $itemEnd;
        }
        //输出下一页
        if ($this->_currentPage < $this->_totalPage) {
            echo $itemNextBegin . sprintf($linkNextBegin,
                str_replace($this->_pageHolder, $this->_currentPage + 1, $this->_pageTemplate) . $this->_anchor. $GLOBALS['can'])
                . $nextWord . $linkEnd . $itemEnd;
        }
    }
}
class Typecho_Widget_Helper_PageNavigator_Classic extends Typecho_Widget_Helper_PageNavigator
{

       

    public function prev($prevWord = 'PREV')
    {$this->_anchor=$GLOBALS['can'];
        //输出上一页
        if ($this->_total > 0 && $this->_currentPage > 1) {
            echo '<a class="prev" href="' . str_replace($this->_pageHolder, $this->_currentPage - 1, $this->_pageTemplate) . $this->_anchor .'">'
            . $prevWord . '</a>';
        }
    }

    public function next($nextWord = 'NEXT')
    {$this->_anchor=$GLOBALS['can'];
        //输出下一页
        if ($this->_total > 0 && $this->_currentPage < $this->_totalPage) {
            echo '<a class="next" title="" href="' . str_replace($this->_pageHolder, $this->_currentPage + 1, $this->_pageTemplate) . $this->_anchor .'">'
            . $nextWord . '</a>';
        }
    }
}
?>
<?php else: ?><?php $this->archiveTitle(array(
            'category'  =>  _t('%s'),
            'search'    =>  _t('检索到包含 %s 的文章'),
            'tag'       =>  _t('标签 %s 下的文章'),
        ), '', ''); ?>
<span class="float-right">共有<?php echo $this->getTotal(); ?>篇</span>
<?php endif; ?></h4>
</div>
</div>
</div>
<div class="row archive">
<?php if ($this->have()): ?>
<?php while($this->next()): ?>
<div class="col-<?php echo $lie[2]; ?> col-md-<?php echo $lie[1]; ?> col-lg-<?php echo $lie[0]; ?>">
 
<div class="card d-block"><div class="card-img-bili">
<a href="<?php $this->permalink() ?>"><img class="card-img-top b-lazy" src="<?php echo theurl; ?>img/load.gif" data-url="<?php showThumbnail($this); ?>" alt="<?php $this->title(); ?>"></a></div>
<div class="card-body">
<a href="<?php $this->permalink() ?>"><h5 class="card-title"><?php $this->title(); ?></h5></a>
<p class="card-text slr"><?php $this->excerpt(90, ''); ?></p>
</div> 
</div> 
</div>

<?php endwhile; ?>

<div class="col-12 mb-1">
<?php if (!empty($this->options->tools) && in_array('pagelist', $this->options->tools)): ?>
<?php $this->pageNav('«', '»', 2, '', array('wrapTag' => 'ul', 'wrapClass' => 'pagination', 'itemTag' => 'li', 'textTag' => 'li', 'currentClass' => 'active', 'prevClass' => 'prev', 'nextClass' => 'next',)); ?>
<?php else: ?>
<?php $this->pageLink('<button type="button" class="btn btn-primary mr-2">上一页</button>'); ?><?php $this->pageLink('<button type="button" class="btn btn-primary">下一页</button>','next'); ?><div class="float-right pt-1"><?php if($this->_currentPage>1) echo $this->_currentPage;  else echo 1;?>/<?php echo   ceil($this->getTotal() / $this->parameter->pageSize); ?></div>
<?php endif; ?>

</div>

<?php else: ?>

<div class="col-12">
<div class="card card-body">
<h5 class="card-title">没有内容</h5>
<p class="card-text">您检索的内容不存在或已被删除</p>
</div> 
</div>

<?php endif; ?>

</div>




















</div>
<?php $this->need('footer.php'); ?>
