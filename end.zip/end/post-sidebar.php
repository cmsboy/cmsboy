<div class="col-md-4" id="sticky">

<div class="card ribbon-box d-none d-md-block">
<div class="card-body">
<div class="ribbon ribbon-info float-left"><i class="mdi mdi-account mr-1"></i> 作者</div>
<div class="media ribbon-content">
<span class="float-left m-2 mr-4">
<img src="<?php tx($this->author->mail); ?>" alt="" class="rounded-circle img-thumbnail">
</span>
<div class="media-body">
<h4 class="mt-1 mb-1"><?php $this->author->screenName(); ?></h4>
<p class="font-13"><a href="<?php $this->author->permalink(); ?>">更多Ta的文章</a></p>
<ul class="mb-0 list-inline">
<li class="list-inline-item mr-3">
<h5 class="mb-1"><?php echo auPublishedPostsNum($this->author->uid) ?>篇</h5>
<p class="mb-0 font-13">作者文章数量</p>
</li>
<li class="list-inline-item">
<h5 class="mb-1"><?php echo auPublishedCommentsNum($this->author->uid) ?>条</h5>
<p class="mb-0 font-13">作者评论数量</p>
</li>
</ul>
</div>
</div>
</div>

</div>

<div class="card ribbon-box<?php if (!in_array('postsidebarbg', $this->options->tools)): ?> bg1<?php endif; ?>">
<div class="card-body">
<?php $this->related(5)->to($relatedPosts); ?><?php if ($relatedPosts->have()): ?>
<div class="ribbon ribbon-success float-left"><i class="mdi mdi-numeric-8-box-multiple mr-1"></i> 相关推荐</div>
<div class="mb-1 shadow-none ribbon-content">

    <?php while ($relatedPosts->next()): ?>
    <a href="<?php $relatedPosts->permalink(); ?>" title="<?php $relatedPosts->title(); ?>"><h5 class="card-title"><?php $relatedPosts->title(); ?></h5></a>
    <?php endwhile; ?>

</div>
<?php else: ?>
<div class="ribbon ribbon-success float-left"><i class="mdi mdi-numeric-8-box-multiple mr-1"></i> 随机推荐</div>
<div class="mb-1 shadow-none ribbon-content">
<?php getRandomPosts(5);?>
</div>
<?php endif; ?>
</div>
</div>


<div class="card ribbon-box<?php if (!in_array('postsidebarbg', $this->options->tools)): ?> bg<?php endif; ?>">
<div class="card-body">
<div class="ribbon ribbon-danger float-left"><i class="mdi mdi-numeric-5-box-multiple mr-1"></i> 热门文章</div>
<div class="mb-1 shadow-none ribbon-content">
<?php $this->widget('Widget_Post_hot@hot', 'pageSize=5')->to($hot); ?>
<?php while($hot->next()): ?>
    <a href="<?php $hot->permalink(); ?>" title="<?php $hot->title(); ?>"><h5 class="card-title"><?php $hot->title(); ?></h5></a>
    <?php endwhile; ?>
</div>
</div>
</div>


<?php if($this->options->ads): ?>
<div class="card">
<div class="card-body">
<?php $this->options->ads(); ?>
</div>
</div>
<?php endif; ?>

<?php if($this->options->ads2): ?>
<div class="card">
<div class="card-body">
<?php $this->options->ads2(); ?>
</div>
</div>
<?php endif; ?>


<?php if($this->options->ads3): ?>
<div class="card">
<div class="card-body">
<?php $this->options->ads3(); ?>
</div>
</div>
<?php endif; ?>







<?php if (!empty($this->options->tools) && in_array('pixiv', $this->options->tools)): ?>
<div class="card ribbon-box">
<div class="card-body">
<div class="ribbon ribbon-primary float-left"><i class="mdi mdi-access-point mr-1"></i> Pixiv日榜Top50</div>
<div class="ribbon-content">
<iframe src="https://cloud.mokeyjay.com/pixiv" frameborder="0" style="width:100%; height:380px;"></iframe>
</div>
</div>
</div>
<?php endif; ?>


</div>