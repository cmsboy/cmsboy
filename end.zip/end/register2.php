<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>注册</title>
    <link rel="stylesheet" href="https://cdn.staticfile.org/tailwindcss/1.2.0/tailwind.min.css">
</head>

<body class="min-h-screen bg-gray-100 text-gray-900 flex justify-center dowebok">
    <div class="max-w-screen-xl m-0 sm:m-20 bg-white shadow sm:rounded-lg flex justify-center flex-1">
        <div class="lg:w-1/2 xl:w-5/12 p-6 sm:p-12">
            <div class="mt-12 flex flex-col items-center">
                <h1 class="text-2xl xl:text-3xl font-extrabold">用户注册</h1>
                <div class="w-full flex-1 mt-8">





<form action="<?php $this->options->registerAction();?>" method="post" name="register" role="form">
                    <div class="mx-auto max-w-xs">


<?php

function unicodeDecode($unicode_str){
    $json = '{"str":"'.$unicode_str.'"}';
    $arr = json_decode($json,true);
    if(empty($arr)) return '';
    return $arr['str'];
}

$p=Typecho_Cookie::getPrefix();
$q=$p.'__typecho_notice';
$y=$p.'__typecho_notice_type';
$px='';$cx='';$mx='';$ux='';$sx='';
if (isset($_COOKIE[$y]) &&($_COOKIE[$y]=='success' || $_COOKIE[$y]=='notice' || $_COOKIE[$y]=='error')){
	if (isset($_COOKIE[$q])){
		?><p class="mb-2 text-xs text-red-500 text-center">
<?php $a=preg_replace('#\[\"(.*?)\"\]#','$1', $_COOKIE[$q]);
echo unicodeDecode($a);
 ?></p>
		<?php
Typecho_Cookie::delete('__typecho_notice');
Typecho_Cookie::delete('__typecho_notice_type');
	}
}
?>

<input type="hidden" name="_" value="<?php echo $this->security->getToken($this->request->getRequestUrl());?>">
<input type="hidden" name="referer" value="<?php $this->options->siteUrl(); ?>?setting">

<input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white" type="text" id="name" name="name" autocomplete="username" placeholder="请输入用户名" required>


<input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white mt-5" type="email" id="mail" name="mail" autocomplete="current-password" placeholder="请输入邮箱" required>

<?php $all = Typecho_Plugin::export(); if(array_key_exists('Rdog', $all['activated'])): ?>
<input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white mt-5" type="password" id="passworda" name="password" autocomplete="current-password" placeholder="输入密码" required>
<input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white mt-5" type="password" id="confirm" name="confirm" autocomplete="current-password" placeholder="再次输入密码" required>
<?php endif; ?>

<?php if(array_key_exists('InvitationCode', $all['activated'])): ?>
<input class="w-full px-8 py-4 rounded-lg font-medium bg-gray-100 border border-gray-200 placeholder-gray-500 text-sm focus:outline-none focus:border-gray-400 focus:bg-white mt-5" type="text" id="code_cxa" name="code_cxa" placeholder="邀请码" value=""/>
<?php endif; ?>






                        <button class="mt-5 tracking-wide font-semibold bg-indigo-500 text-gray-100 w-full py-4 rounded-lg hover:bg-indigo-700 ease-in-out flex items-center justify-center focus:shadow-outline focus:outline-none" type="submit">
                            <span>注 册</span>
                        </button>           
                    </div>
</form>
                    












<div class="flex flex-col items-center">






                    </div>








                </div>
            </div>
        </div>
        <div class="flex-1 bg-indigo-100 text-center hidden lg:flex">
            <div class="m-12 xl:m-16 w-full bg-contain bg-center bg-no-repeat" style="background-image: url('<?php echo theurl; ?>img/dowebok.svg');"></div>
        </div>
    </div>






<script>
function OW(url)
{
    window.open(url, "_blank");
}
</script>


</body>
</html>
<?php exit; ?>