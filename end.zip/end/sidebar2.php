<div class="topnav">
    <div class="container-fluid">
        <nav class="navbar navbar-<?php if($this->options->leftsidebar && $this->options->leftsidebar=="light"){echo 'light';}else{echo 'dark';} ?> navbar-expand-lg topnav-menu">
        
            <div class="collapse navbar-collapse" id="topnav-menu-content">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link" href="<?php $this->options->rootUrl(); ?>/">首页</a>
                        
                    </li>

















<?php $this->widget('Widget_Metas_Category_List')->to($categorys); ?>
<?php while($categorys->next()): ?>
<?php if ($categorys->levels === 0): ?>
<?php $children = $categorys->getAllChildren($categorys->mid); ?>
<?php if (empty($children)) { ?>
<li class="nav-item dropdown">
<a class="nav-link <?php if($this->is('category', $categorys->slug)): ?>active<?php endif; ?>" href="<?php $categorys->permalink(); ?>"><?php $categorys->name(); ?></a>
</li>
<?php } else { ?>
<li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-apps" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<?php $categorys->name(); ?><div class="arrow-down"></div>
                        </a>
  <div class="dropdown-menu" aria-labelledby="topnav-apps">
<?php foreach ($children as $mid) { ?>
<?php $child = $categorys->getCategory($mid); ?>
                                    <a href="<?php echo $child['permalink'] ?>" class="dropdown-item <?php if($this->is('category', $mid)): ?>active<?php endif; ?>"><?php echo $child['name']; ?></a>
<?php } ?>
                                </div>
                           </li>
<?php } ?><?php endif; ?><?php endwhile; ?>



                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-pages" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
关于<div class="arrow-down"></div>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="topnav-pages">
 <?php $this->widget('Widget_Contents_Page_List')->to($pages); ?>
                    <?php while($pages->next()): ?>
                            <a href="<?php $pages->permalink(); ?>" class="dropdown-item <?php if($this->is('page', $pages->slug)): ?>active<?php endif; ?>"><?php $pages->title(); ?></a>
 <?php endwhile; ?>
                        </div>
                    </li>      
 <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search">   
<div class="input-group mt-3 mb-3 d-md-none">
<input type="text" name="ss" class="form-control" placeholder="Search" aria-label="Search">
<div class="input-group-append"> <button class="btn btn-primary" type="submit">搜索</button>
</div>
</div>
</form>
                </ul>
            </div>
        </nav>
    </div>
</div>