<?php if(!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div class="container-fluid">
<style>
.text-error {
    color: #727cf5;
    text-shadow: rgba(114,124,245,.3) 5px 1px, rgba(114,124,245,.2) 10px 3px;
    font-size: 5.25rem;
    line-height: 5.625rem;
}
.card-header, .card-title {
    color: #fff;
    font-size: 1.2rem;
}
body[data-leftbar-theme=light] .bg-primary {
   background-color: #39afd1 !important;
}
</style>

<div class="container pr-0 pl-0">
<div class="row justify-content-center mt-5">
<div class="col-lg-5">
<div class="card">

<div class="card-header pt-4 pb-4 text-center bg-primary">
登录
</div>
<div class="card-body p-4">
<form action="<?php $this->options->loginAction()?>" method="post" name="login" rold="form">


<div class="form-group">
<label for="emailaddress">用户名</label>
<input class="form-control" type="text" id="name" name="name" autocomplete="username" placeholder="请输入用户名" required>
</div>
<div class="form-group">
<label for="password">密码</label>
<input class="form-control" type="password" id="password" name="password" autocomplete="current-password" placeholder="请输入密码" required>
<input type="hidden" name="referer" value="<?php $this->options->siteUrl(); ?>">
</div>
<div class="form-group mb-2">
<div class="custom-control custom-checkbox">
<input type="checkbox" class="custom-control-input" id="checkbox-signin" name="remember" value="1">
<label class="custom-control-label" for="checkbox-signin">下次自动登录</label>
</div>
</div>
<div class="form-group mb-0">
<button class="btn btn-primary mb-1 mr-1" type="submit"> 登录 </button>



<?php if (!empty($this->options->tools) && in_array('QQConnect', $this->options->tools)): ?>
<a href="javascript: void(0);" onclick="OW('<?php $this->options->rootUrl(); ?>/<?php if ($this->options->rewrite==0): ?>index.php/<?php endif; ?>oauth?type=qq')" class="btn btn-primary mb-1 mr-1" rel="external nofollow" data-toggle="tooltip" data-original-title="使用QQ登录!"><i class="mdi mdi-qqchat"></i></a>
<?php endif; ?>
<?php if (!empty($this->options->tools) && in_array('weiboConnect', $this->options->tools)): ?>
<a href="javascript: void(0);" onclick="OW('<?php $this->options->rootUrl(); ?>/<?php if ($this->options->rewrite==0): ?>index.php/<?php endif; ?>oauth?type=weibo')" class="btn btn-primary mb-1" rel="external nofollow" data-toggle="tooltip" data-original-title="使用微博登录!"><i class="mdi mdi-sina-weibo"></i></a>
<?php endif; ?>
<?php if($this->options->allowRegister): ?>&nbsp;&nbsp;<a href="<?php $this->options->rootUrl(); ?>?register" class="btn btn-info mb-1">注册</a><?php endif; ?>


</div>
</form>
</div> 
</div>



</div> 
</div>

</div>






</div>
</div>