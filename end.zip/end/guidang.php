<?php 
/**
 * 归档
 * 
 * @package custom 
 * 
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
 $this->need('header.php');
 $this->need('sidebar.php');
?> 

<div class="container-fluid">

          <div class="row">

<?php $this->widget('Widget_Contents_Post_Recent', 'pageSize=10000')->to($archives);   
    $year=0; $mon=0; $i=3; $n=0;
 $ml = $archives->options->rootUrl;
   $output = ''; 
    while($archives->next()):   

        $y = date('Y',$archives->created);   
        $m = date('m',$archives->created);



if($y!=$year && $year>0){
   $output .= ''; //年后内容
}

if($m!=$mon && $mon>0){$n=0;
   $output .= '</div></div></div></div>'; //月末内容
}

if($y!=$year){$year=$y;
   $output .= '<div class="col-12"><h3 class="">'.$y.'年</h3></div>'; //年前内容
}

if($m!=$mon){$mon=$m;


if($i>0){$i--;
$zt="true";$sh=" show";
}else{
$zt="false";$sh="";
}


   $output .= '<div class="col-12">
<div class="card">
<div class="card-header" id="os-'.$m.'">
<h5 class="m-0">
<a class="custom-accordion-title d-block pt-2 pb-2 collapsed" data-toggle="collapse" href="#xos-'.$m.'" aria-expanded="'.$zt.'" aria-controls="xos-'.$m.'">'.$m.'月<span class="float-right"><i class="mdi mdi-chevron-down accordion-arrow"></i></span>
</a>
</h5>
</div>
<div id="xos-'.$m.'" class="collapse'.$sh.'" aria-labelledby="os-'.$m.'">
<div class="card-body pt-0">'; //月初内容
}


$n++; 
$output .= '<div class="col pl-0 pr-0 pt-3">'.$n.'、<a class="card-link" href="'.$archives->permalink .'">'. $archives->title .'</a></div>'; 

           



    endwhile;   
   $output .= '</div></div></div>'; //月末内容
    echo $output;  
?>  







</div>
</div>
</div>

<?php $this->need('footer.php'); ?>