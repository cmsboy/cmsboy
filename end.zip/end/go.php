<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; 
if(isset($_GET['go'])&&isset($_GET['url'])){
$url=base64_decode($_GET['url']);

if(strpos($url,'javascript:') !==false||strpos($url,'<script') !==false){
echo '非法链接';exit;
}




}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>即将跳转到外部网站 - <?php $this->options->title(); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="<?php echo theurl; ?>assets/css/icons.min.css?1" rel="stylesheet" type="text/css" />
<link href="<?php echo theurl; ?>assets/css/app.min.css?1" rel="stylesheet" type="text/css" />
<style>
.text-error {
    color: #727cf5;
    text-shadow: rgba(114,124,245,.3) 5px 1px, rgba(114,124,245,.2) 10px 3px;
    font-size: 5.25rem;
    line-height: 5.625rem;
}
.card-header, .card-title {
    color: #fff;
    font-size: 1.2rem;
}
</style>
</head>
<body class="authentication-bg">
<div class="account-pages mt-5 mb-5">
<div class="container">
<div class="row justify-content-center">
<div class="col-lg-5">
<div class="card">

<div class="card-header pt-4 pb-4 text-center bg-primary">
即将跳转到外部网站
</div>
<div class="card-body p-4">
<div class="text-center">
<h1 class="text-error"><i class="mdi mdi-emoticon-sad"></i></h1>
<h4 class="text-uppercase text-danger mt-3"><span id="time">5</span>秒后自动跳转</h4>
<p class="text-muted mt-3">安全性未知，是否继续</p>
<a class="btn btn-info mt-3" href="<?php echo $url; ?>">继续前往</a>
</div>
</div> 
</div>

</div> 
</div>

</div>

</div>





<script type="text/javascript"> 
    var t = 5;//设定跳转的时间 
    var interval = setInterval("refer()", 1000); //启动1秒定时 
    function refer() {
        if (t == 0){clearInterval(interval);//停止计时
            window.location.href = "<?php echo $url; ?>"; //跳转的地址
        }
        $('#time').text(t); // 显示倒计时 
        t--; // 计数器递减 
    } 
</script>
<script src="<?php echo theurl; ?>assets/js/app.min.js?0"></script>
</body>
</html>
