var fy=fancybox;
/*!
 * jquery.scrollLoading.js
 * by zhangxinxu http://www.zhangxinxu.com/wordpress/?p=1259
 * 轻度魔改不适合他人，需要代码请进↑链接处获取纯净源码
*/
(function(a){a.fn.scrollLoading=function(b){var c={attr:"data-url",type:"data-type",container:a(window),callback:a.noop};var d=a.extend({},c,b||{});d.cache=[];a(this).each(function(){var h=this.nodeName.toLowerCase(),g=a(this).attr(d.attr);t=a(this).attr(d.type);var i={obj:a(this),tag:h,type:t,url:g};d.cache.push(i)});var f=function(g){if(a.isFunction(d.callback)){d.callback.call(g.get(0))}};var e=function(){var g=d.container.height();if(d.container.get(0)===window){contop=a(window).scrollTop()}else{contop=d.container.offset().top}a.each(d.cache,function(m,n){var p=n.obj,j=n.tag,k=n.url,t=n.type,l,h;if(p){l=p.offset().top-contop,h=l+p.height();if((l>=0&&l<g)||(h>0&&h<=g)){if(k){if(j==="img"){if(t=="qqtx"){$.get(k,function(result){var k=jQuery.parseJSON(result).url;f(p.attr("src",k))})}else{var oI = new Image();oI.src = k;oI.onload = function() {f(p.attr("src",oI.src));};}}else{p.load(k,{},function(){f(p)})}}else{f(p)}n.obj=null}}})};e();d.container.bind("scroll",e)}})(jQuery);
/*!
 * Theia Sticky Sidebar v1.7.0
 * https://github.com/WeCodePixels/theia-sticky-sidebar
 *
 * Glues your website's sidebars, making them permanently visible while scrolling.
 *
 * Copyright 2013-2016 WeCodePixels and other contributors
 * Released under the MIT license
 */
(function($){$.fn.theiaStickySidebar=function(options){var defaults={"containerSelector":"","additionalMarginTop":0,"additionalMarginBottom":0,"updateSidebarHeight":true,"minWidth":0,"disableOnResponsiveLayouts":true,"sidebarBehavior":"modern","defaultPosition":"relative","namespace":"TSS"};options=$.extend(defaults,options);options.additionalMarginTop=parseInt(options.additionalMarginTop)||0;options.additionalMarginBottom=parseInt(options.additionalMarginBottom)||0;tryInitOrHookIntoEvents(options,this);function tryInitOrHookIntoEvents(options,$that){var success=tryInit(options,$that);if(!success){console.log("TSS: Body width smaller than options.minWidth. Init is delayed.");$(document).on("scroll."+options.namespace,function(options,$that){return function(evt){var success=tryInit(options,$that);if(success){$(this).unbind(evt)}}}(options,$that));$(window).on("resize."+options.namespace,function(options,$that){return function(evt){var success=tryInit(options,$that);if(success){$(this).unbind(evt)}}}(options,$that))}}function tryInit(options,$that){if(options.initialized===true){return true}if($("body").width()<options.minWidth){return false}init(options,$that);return true}function init(options,$that){options.initialized=true;var existingStylesheet=$("#theia-sticky-sidebar-stylesheet-"+options.namespace);if(existingStylesheet.length===0){$("head").append($('<style id="theia-sticky-sidebar-stylesheet-'+options.namespace+'">.theiaStickySidebar:after {content: ""; display: table; clear: both;}</style>'))}$that.each(function(){var o={};o.sidebar=$(this);o.options=options||{};o.container=$(o.options.containerSelector);if(o.container.length==0){o.container=o.sidebar.parent()}o.sidebar.parents().css("-webkit-transform","none");o.sidebar.css({"position":o.options.defaultPosition,"overflow":"visible","-webkit-box-sizing":"border-box","-moz-box-sizing":"border-box","box-sizing":"border-box"});o.stickySidebar=o.sidebar.find(".theiaStickySidebar");if(o.stickySidebar.length==0){var javaScriptMIMETypes=/(?:text|application)\/(?:x-)?(?:javascript|ecmascript)/i;o.sidebar.find("script").filter(function(index,script){return script.type.length===0||script.type.match(javaScriptMIMETypes)}).remove();o.stickySidebar=$("<div>").addClass("theiaStickySidebar").append(o.sidebar.children());o.sidebar.append(o.stickySidebar)}o.marginBottom=parseInt(o.sidebar.css("margin-bottom"));o.paddingTop=parseInt(o.sidebar.css("padding-top"));o.paddingBottom=parseInt(o.sidebar.css("padding-bottom"));var collapsedTopHeight=o.stickySidebar.offset().top;var collapsedBottomHeight=o.stickySidebar.outerHeight();o.stickySidebar.css("padding-top",1);o.stickySidebar.css("padding-bottom",1);collapsedTopHeight-=o.stickySidebar.offset().top;collapsedBottomHeight=o.stickySidebar.outerHeight()-collapsedBottomHeight-collapsedTopHeight;if(collapsedTopHeight==0){o.stickySidebar.css("padding-top",0);o.stickySidebarPaddingTop=0}else{o.stickySidebarPaddingTop=1}if(collapsedBottomHeight==0){o.stickySidebar.css("padding-bottom",0);o.stickySidebarPaddingBottom=0}else{o.stickySidebarPaddingBottom=1}o.previousScrollTop=null;o.fixedScrollTop=0;resetSidebar();o.onScroll=function(o){if(!o.stickySidebar.is(":visible")){return}if($("body").width()<o.options.minWidth){resetSidebar();return}if(o.options.disableOnResponsiveLayouts){var sidebarWidth=o.sidebar.outerWidth(o.sidebar.css("float")=="none");if(sidebarWidth+50>o.container.width()){resetSidebar();return}}var scrollTop=$(document).scrollTop();var position="static";if(scrollTop>=o.sidebar.offset().top+(o.paddingTop-o.options.additionalMarginTop)){var offsetTop=o.paddingTop+options.additionalMarginTop;var offsetBottom=o.paddingBottom+o.marginBottom+options.additionalMarginBottom;var containerTop=o.sidebar.offset().top;var containerBottom=o.sidebar.offset().top+getClearedHeight(o.container);var windowOffsetTop=0+options.additionalMarginTop;var windowOffsetBottom;var sidebarSmallerThanWindow=(o.stickySidebar.outerHeight()+offsetTop+offsetBottom)<$(window).height();if(sidebarSmallerThanWindow){windowOffsetBottom=windowOffsetTop+o.stickySidebar.outerHeight()}else{windowOffsetBottom=$(window).height()-o.marginBottom-o.paddingBottom-options.additionalMarginBottom}var staticLimitTop=containerTop-scrollTop+o.paddingTop;var staticLimitBottom=containerBottom-scrollTop-o.paddingBottom-o.marginBottom;var top=o.stickySidebar.offset().top-scrollTop;var scrollTopDiff=o.previousScrollTop-scrollTop;if(o.stickySidebar.css("position")=="fixed"){if(o.options.sidebarBehavior=="modern"){top+=scrollTopDiff}}if(o.options.sidebarBehavior=="stick-to-top"){top=options.additionalMarginTop}if(o.options.sidebarBehavior=="stick-to-bottom"){top=windowOffsetBottom-o.stickySidebar.outerHeight()
}if(scrollTopDiff>0){top=Math.min(top,windowOffsetTop)}else{top=Math.max(top,windowOffsetBottom-o.stickySidebar.outerHeight())}top=Math.max(top,staticLimitTop);top=Math.min(top,staticLimitBottom-o.stickySidebar.outerHeight());var sidebarSameHeightAsContainer=o.container.height()==o.stickySidebar.outerHeight();if(!sidebarSameHeightAsContainer&&top==windowOffsetTop){position="fixed"}else{if(!sidebarSameHeightAsContainer&&top==windowOffsetBottom-o.stickySidebar.outerHeight()){position="fixed"}else{if(scrollTop+top-o.sidebar.offset().top-o.paddingTop<=options.additionalMarginTop){position="static"}else{position="absolute"}}}}if(position=="fixed"){var scrollLeft=$(document).scrollLeft();o.stickySidebar.css({"position":"fixed","width":getWidthForObject(o.stickySidebar)+"px","transform":"translateY("+top+"px)","left":(o.sidebar.offset().left+parseInt(o.sidebar.css("padding-left"))-scrollLeft)+"px","top":"0px"})}else{if(position=="absolute"){var css={};if(o.stickySidebar.css("position")!="absolute"){css.position="absolute";css.transform="translateY("+(scrollTop+top-o.sidebar.offset().top-o.stickySidebarPaddingTop-o.stickySidebarPaddingBottom)+"px)";css.top="0px"}css.width=getWidthForObject(o.stickySidebar)+"px";css.left="";o.stickySidebar.css(css)}else{if(position=="static"){resetSidebar()}}}if(position!="static"){if(o.options.updateSidebarHeight==true){o.sidebar.css({"min-height":o.stickySidebar.outerHeight()+o.stickySidebar.offset().top-o.sidebar.offset().top+o.paddingBottom})}}o.previousScrollTop=scrollTop};o.onScroll(o);$(document).on("scroll."+o.options.namespace,function(o){return function(){o.onScroll(o)}}(o));$(window).on("resize."+o.options.namespace,function(o){return function(){o.stickySidebar.css({"position":"static"});o.onScroll(o)}}(o));if(typeof ResizeSensor!=="undefined"){new ResizeSensor(o.stickySidebar[0],function(o){return function(){o.onScroll(o)}}(o))}function resetSidebar(){o.fixedScrollTop=0;o.sidebar.css({"min-height":"1px"});o.stickySidebar.css({"position":"static","width":"","transform":"none"})}function getClearedHeight(e){var height=e.height();e.children().each(function(){height=Math.max(height,$(this).height())});return height}})}function getWidthForObject(object){var width;try{width=object[0].getBoundingClientRect().width}catch(err){}if(typeof width==="undefined"){width=object.width()}return width}return this}})(jQuery);

function OW(url)
{
    window.open(url, "_blank");
}

function fancy(){
$(".post img,.page img").each(function() {
  var element = document.createElement("a");
  $(element).attr("data-fancybox", "gallery");
  $(element).attr("href", $(this).attr("src"));
$(element).attr("data-caption", $(this).attr("alt"));
  $(this).wrap(element);
});
}





jQuery(document).ready(function($) {
        // Scroll to Top
        $(window).scroll(function () {
            if ($(this).scrollTop() >= 50) {
                $('#widget-to-top').fadeIn(200);
            } else {
                $('#widget-to-top').fadeOut(200);
            }
        });
        $('.btn-totop').click(function () {
            $('body,html').animate({
                scrollTop: 0
            }, 500);
        });

if(!$("#nojia").length > 0){
    //点击下一页的链接(即那个a标签)
    $('.next span').click(function() {
        $this = $(this);
        $this.addClass('loading').text('正在努力加载'); //给a标签加载一个loading的class属性，用来添加加载效果
        var href =  $('li.next a').attr('href');
        if (href != undefined) { //如果地址存在
            $.ajax({ //发起ajax请求
                url: href,
                //请求的地址就是下一页的链接
                type: 'get',
                //请求类型是get
                error: function(request) {
                    //如果发生错误怎么处理
                },
                success: function(data) { //请求成功
                    $this.removeClass('loading').text('点击加载更多'); //移除loading属性
                    var $res = $(data).find('.hang'); //从数据中挑出文章数据，请根据实际情况更改
                    $('#comments > .comment-list').append($res.fadeIn(500)); //将数据加载加进posts-loop的标签中。
$(".b-lazy").scrollLoading({callback: function() {$(this).removeAttr("data-type");$(this).removeAttr("data-url");$(this).addClass("ojbk");}});//重载头像懒加载
                    var newhref = $(data).find('li.next a').attr('href');
                    if (newhref != undefined) {
 $('li.next a').attr('href', newhref);
                    } else {
                        $('.next').remove(); //如果没有下一页了，隐藏
                    }
                }
            });
        }
        return false;
    });
}
});


$("#flsou").bind("change",function(){
var bq=$(this).find("option:selected").val();
        $("#scbar_mod").val(bq);

    });


$(function () {
if(fy==1){fancy();}
/*图片滚动加载*/
$(".b-lazy").scrollLoading({callback: function() {$(this).removeAttr("data-type");$(this).removeAttr("data-url");$(this).addClass("ojbk");}
});


if($('#sticky').length > 0){
$('#sticky').theiaStickySidebar({
		additionalMarginTop: 0,
		additionalMarginBottom: 61
	});
}


/*评论表情配置*/
if($(".OwO").length > 0) {
var OwO_demo = new OwO({
            container: document.getElementsByClassName('OwO')[0],
            target: document.getElementsByClassName('OwO-textarea')[0],
            api: '/usr/themes/end/assets/OwO.json',
            position: 'down',
            width: '66vw',
            maxHeight: '250px'
});
}
  
/*ajax评论*/
//监听评论表单提交
$('#comment-form').submit(function(){
        var form = $(this), params = form.serialize();
        // 添加functions.php中定义的判断参数
        params += '&themeAction=comment';
        
        // 解析新评论并附加到评论列表
        var appendComment = function(comment){
            // 评论列表
            var el = $('#comments > .comment-list');
            var pl = " comment-parent";
            if(0 != comment.parent){var pl = "";
                // 子评论则重新定位评论列表
                var el = $('#li-comment-'+comment.parent);
                // 父评论不存在子评论时
                if(el.find('.comment-children').length < 1){
                    $('<div class="comment-children"><ol class="comment-list"></ol></div>').appendTo(el);
                }else if(el.find('.comment-children > .comment-list').length <1){
                    $('<ol class="comment-list"></ol>').appendTo(el.find('.comment-children'));
                }
                el = $('#li-comment-'+comment.parent).find('.comment-children').find('.comment-list');
            }
            if(0 == el.length){
                $('<ol class="comment-list"></ol>').appendTo($('#comments'));
                el = $('#comments > .comment-list');
            }
                        // 评论html模板，根据具体主题定制
            var html = '<div id="li-comment-{coid}" class="comment-body'+pl+' comment-ajax"><div class="media mt-2"><img class="mr-3 avatar-sm rounded-circle b-lazy ojbk" src="{avatar}" alt="Generic placeholder image"><div class="media-body"><div id="comment-2"><h5 class="mt-0"><a href="{permalink}" target="_blank" rel="external nofollow">{author}</a>  {status}</h5>{content}<p class="text-muted mb-0"><span class="mr-1">{sf}</span><span class="mr-1">{os}</span><span class="mr-1"><i class="mdi mdi-timer"></i> 刚刚</span></p></div></div></div></div>';
            $.each(comment,function(k,v){
                regExp = new RegExp('{'+k+'}', 'g');
                html = html.replace(regExp, v);
            });
if($(".reply2view").length > 0) {
            $.ajax({ 
                url: url,
                type: 'get',
                error: function(request) {$.NotificationApp.send("警告!","回复可见内容需要刷新页面后可见！","top-center","rgba(0,0,0,0.2)","warning");},
                success: function(data) {
                    if($(data).find('.reply2view-ok').length>0){
                    var $res = $(data).find('.reply2view-ok'); 
                    $('.reply2view').after($res.fadeIn(500));
                    $(".reply2view").remove();$.NotificationApp.send("提示!","回复可见内容已成功为您显示！","top-center","rgba(0,0,0,0.2)","success");
                   }}
            });
}
            $(html).prependTo(el);
        };
        // ajax提交评论
        $.ajax({
            url: url,
            type: 'POST',
            data: params,
            dataType: 'json',
            beforeSend: function() { form.find('#misubmit').addClass('loading').html('<span class="spinner-border spinner-border-sm mr-1" role="status" aria-hidden="true"></span>提交中...').attr('disabled','disabled');},
            complete: function() { form.find('#misubmit').removeClass('loading').html('提交').removeAttr('disabled');},
            success: function(result){
                if(1 == result.status){
                    // 新评论附加到评论列表
                    appendComment(result.comment);
                    form.find('textarea').val('');
TypechoComment.cancelReply();
                }else{
                    // 提醒错误消息
                    var tishi=undefined === result.msg ? '评论出错!' : result.msg;
$.NotificationApp.send("警告!",tishi,"top-center","rgba(0,0,0,0.2)","warning");
                }
            },
            error:function(xhr, ajaxOptions, thrownError){
$.NotificationApp.send("提示!","评论提交失败请重试","top-center","rgba(0,0,0,0.2)","error");}
        });
return false;
});


$(".protected").submit(function() {
var surl=$(".protected").attr("action");
$.ajax({
                type: "POST",
                url:surl,
                data:$('.protected').serialize(),// 你的formid
                async:true,
                error: function(request) {
$.NotificationApp.send('提示!','密码提交失败，请刷新页面重试！','top-center','rgba(0,0,0,0.2)','error');
                },
                success: function(data) {
if(data.indexOf("密码错误") >= 0 && (data.indexOf("<title>Error</title>") >= 0 || data.indexOf("Typecho_Widget_Exception") >= 0)) {
$.NotificationApp.send('提示!','密码错误，请重试！','top-center','rgba(0,0,0,0.2)','error');
}else{
location.reload();//密码正确刷新页面
}
                }
});
return false;
});

});