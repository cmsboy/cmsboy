<?php
/**
 * “ 那些坚定决心的人们，会展现出好脸色。 ”
 * 
 * @package End
 * @author 龙某
 * @version 不出意外最终版（不包括bug修复版）
 * @link https://cmsboy.cn/archives/end-1.html
 */
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
if(isset($_GET['go'])&&isset($_GET['url'])){
 $this->need('go.php'); }else{

if((isset($_GET['register'])&&!$this->user->hasLogin()&&$this->options->allowRegister) || (isset($_GET['login'])&&!$this->user->hasLogin())){
if(($this->options->dl && $this->options->dl=='2')){}else{
 $this->need('header.php');
 $this->need('sidebar.php');
}
}else{
 $this->need('header.php');
 $this->need('sidebar.php');
}

$lie= Helper::options()->freestyle ? explode(',', strtr(Helper::options()->freestyle, ' ', ',')) : array("3","6","12");
 ?>


<?php if(isset($_GET['register'])&&!$this->user->hasLogin()&&$this->options->allowRegister): ?>
<?php if (array_key_exists('TePass', Typecho_Plugin::export()['activated'])){Header("Location:".$this->options->logoUrl."/tepass/signup"); } ?>
<?php  if(($this->options->dl && $this->options->dl=='2')){$this->need('register2.php');}else{$this->need('register.php');} ?>
<?php else: ?>
<?php if(isset($_GET['login'])&&!$this->user->hasLogin()): ?>
<?php if (array_key_exists('TePass', Typecho_Plugin::export()['activated'])){Header("Location:".$this->options->logoUrl."/tepass/signin"); } ?>
<?php  if(($this->options->dl && $this->options->dl=='2')){$this->need('login2.php');}else{$this->need('login.php');} ?>
<?php else: ?>
<?php if(isset($_GET['setting'])&&$this->user->hasLogin()): ?>
<?php  $this->need('setting.php'); ?>
<?php else: ?>
<div class="container-fluid mb-3">

<div class="row">
<div class="col-12">
<div class="page-title-box">
<div class="page-title-right">

</div>

<?php if($this->options->fengge!=2): ?>
 <form method="post" action="<?php $this->options->siteUrl(); ?>" role="search">   
<div class="input-group mt-3 mb-3 d-md-none">
<input type="text" name="ss" class="form-control" placeholder="Search" aria-label="Search">
<div class="input-group-append"> <button class="btn btn-primary" type="submit">搜索</button>
</div>
</div>
</form>
<?php else: ?>
<div class="mt-3"></div>
<?php endif; ?>
</div>
</div>
</div>


<?php if($this->_currentPage<2 && $this->options->lunbo): ?>

<?php 
$txt=$this->options->lunbo;
$string_arr = explode("\r\n", $txt);
$long=count($string_arr);
?>

<div class="row">
<div class="col-12 col-md-6 mb-3">

<div id="lunbo" class="carousel slide" data-ride="carousel">
 
    <!-- 指示符 -->
<ul class="carousel-indicators mb-0 mr-1" style="left: auto;bottom: auto;">
<?php 
for($i=0;$i<$long;$i++){$av="";if($i==0){$av='class="active"';}
echo '<li data-target="#lunbo" data-slide-to="'.$i.'" '.$av.'></li>';}
?>
    </ul>
 
    <!-- 轮播图片 -->
    <div class="carousel-inner lunbo">


<?php 
for($i=0;$i<$long;$i++){$av="";if($i==0){$av='active';}
$id=explode("$",$string_arr[$i])[0];
$tu=explode("$",$string_arr[$i])[1];
$this->widget('Widget_Archive@lunbo'.$i, 'pageSize=1&type=single', 'cid='.$id)->to($ji);
echo '<div class="carousel-item ze-over '.$av.'"><a href="'.$ji->permalink.'"><img src="'.$tu.'"></a><a href="'.$ji->permalink.'"><div class="zeze-over"><span class="title">'.$ji->title.'</span></div></a></div>';
}
?>


    </div>
 
    <!-- 左右切换按钮 
    <a class="carousel-control-prev" href="#lunbo" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#lunbo" data-slide="next">
        <span class="carousel-control-next-icon"></span>
    </a>-->
</div>
</div>
<div class="col-12 col-md-6 mb-3">
<div class="row">

<?php if($this->options->tuijian): ?>
<?php 
$tuijian=$this->options->tuijian;
$tuijianzu = explode(",", $tuijian);
$number=count($tuijianzu);
for($i=0;$i<$number;$i++){
?>
<?php $this->widget('Widget_Archive@tuijian'.$i, 'pageSize=1&type=post', 'cid='.$tuijianzu[$i])->to($tui); ?>
<div class="col-<?php if($i == 0){echo '12 mb5';}
if($i == 1){echo '6 mt5 pr-1';}
if($i == 2){echo '6 mt5 pl-1';}?>">
<div class="ze-over">
<a href="<?php $tui->permalink() ?>"><img src="<?php showThumbnail($tui); ?>" alt="<?php $tui->title(); ?>"></a>
<a href="<?php $tui->permalink() ?>"><div class="zeze-over"><span class="title"><?php $tui->title(); ?></span></div></a>
</div></div>
<?php } ?>




<?php else: ?>
<?php $this->widget('Widget_Post_hot@hot', 'pageSize=3')->to($hot); ?>
<?php while($hot->next()): ?>
<div class="col-<?php if($hot->sequence == 1){echo '12 mb5';}
if($hot->sequence == 2){echo '6 mt5 pr-1';}
if($hot->sequence == 3){echo '6 mt5 pl-1';}?>">
<div class="ze-over">
<a href="<?php $hot->permalink() ?>"><img src="<?php showThumbnail($hot); ?>" alt="<?php $hot->title(); ?>"></a>
<a href="<?php $hot->permalink() ?>"><div class="zeze-over"><span class="title"><?php $hot->title(); ?></span></div></a>
</div></div>
 <?php endwhile; ?>
<?php endif; ?>
</div>
</div>
</div>

<?php endif; ?>
<div class="row archive">
<?php if($this->options->cms): ?>
<?php $this->need('cms.php'); ?>
<?php else: ?>

<?php $all = Typecho_Plugin::export(); if(array_key_exists('Sticky', $all['activated'])): ?>
<?php 
$zd=Typecho_Widget::widget('Widget_Options')->plugin('Sticky');
$zd = $zd->sticky_cids ? explode(',', strtr($zd->sticky_cids, ' ', ',')) : '';
if(!empty($zd)){
$num = count($zd);
$z=intval(floor($num/4));
if($num%4!=0){$y=intval(floor(12/($num%4)));}else{$y=0;}
$x=$z*4;
$n=1;
}
?>
<?php endif; ?>

<?php if ($this->have()): ?>
<?php while($this->next()): ?>
<?php if($this->sticky): ?>
<div class="col-md-<?php if($n<=$x){echo '3';}else{echo $y;}$n++; ?>">
 
<div class="card d-block">

<div class="card-body">
<a href="<?php $this->permalink() ?>"><h5 class="card-title"><?php $this->sticky(); $this->title(); ?></h5></a>
<a href="<?php $this->permalink() ?>" class="btn btn-primary">阅读文章</a>
</div> 
</div>
</div><?php else: ?>


<div class="col-<?php echo $lie[2]; ?> col-md-<?php echo $lie[1]; ?> col-lg-<?php echo $lie[0]; ?>">
 
<div class="card d-block"><div class="card-img-bili">
<a href="<?php $this->permalink() ?>"><img class="card-img-top b-lazy" src="<?php echo theurl; ?>img/load.gif" data-url="<?php showThumbnail($this); ?>" alt="<?php $this->title(); ?>"></a></div> 
<div class="card-body">
<a href="<?php $this->permalink() ?>"><h5 class="card-title"><?php $this->title(); ?></h5></a>
<p class="card-text slr"><?php $this->excerpt(90, ''); ?></p>
<a href="<?php $this->permalink() ?>" class="btn btn-primary">阅读文章</a>
</div> 
</div> 
</div>
<?php endif; ?>
<?php endwhile; ?>

<div class="col-12 mb-1">
<?php if (!empty($this->options->tools) && in_array('pagelist', $this->options->tools)): ?>
<?php $this->pageNav('«', '»', 2, '', array('wrapTag' => 'ul', 'wrapClass' => 'pagination', 'itemTag' => 'li', 'textTag' => 'li', 'currentClass' => 'active', 'prevClass' => 'prev', 'nextClass' => 'next',)); ?>
<?php else: ?>
<?php $this->pageLink('<button type="button" class="btn btn-primary mr-2">上一页</button>'); ?><?php $this->pageLink('<button type="button" class="btn btn-primary">下一页</button>','next'); ?><div class="float-right pt-1"><?php if($this->_currentPage>1) echo $this->_currentPage;  else echo 1;?>/<?php echo   ceil($this->getTotal() / $this->parameter->pageSize); ?></div>
<?php endif; ?>
</div>

<?php else: ?>
<div class="col-12">
<div class="card card-body">
<h5 class="card-title">没有内容</h5>
<p class="card-text">您检索的内容不存在或已被删除</p>
</div> 
</div>
<?php endif; ?>
<?php endif; ?>
</div>


</div><?php endif; ?><?php endif; ?><?php endif; ?>
<?php $this->need('footer.php'); ?><?php } ?>