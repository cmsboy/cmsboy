<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php if(!$this->request->isAjax()): ?><?php  $this->need('header.php');
 $this->need('sidebar.php'); ?><?php endif; ?>
<?php if ($this->fields->mp4||$this->fields->m3u8): ?><?php $this->need('video.php'); ?>
<?php else: ?>
<div class="container-fluid mt-4">

<div class="row">
<div class="col-md-8">

<div class="card d-block">
<div class="card-body post">
<?php if($this->user->uid==$this->authorId):?>
<div class="dropdown float-right">
<a href="#" class="dropdown-toggle arrow-none card-drop" data-toggle="dropdown" aria-expanded="false">
<i class="dripicons-dots-3"></i>
</a>
<div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end">
<?php Typecho_Widget::widget('Widget_Security')->to($security); ?>
<a href="<?php $this->options->adminUrl(); ?>write-post.php?cid=<?php echo $this->cid;?>" class="dropdown-item"><i class="mdi mdi-pencil mr-1"></i>编辑文章</a>
<!--<a href="<?php $security->index('/action/contents-post-edit?do=delete&cid='.$this->cid); ?>" onclick="return p_del();" class="dropdown-item"><i class="mdi mdi-delete mr-1"></i>Delete</a>-->
</div>
</div>
<?php endif;?>

<h3 class="mt-0">
<?php $this->title(); ?>
</h3>

<span class="badge badge-primary-lighten mb-1">
<?php $this->category('</span> <span class="badge badge-primary-lighten mb-1">', true, '无分类'); ?></span> <span class="badge badge-secondary-lighten mb-1"><?php $this->tags('</span> <span class="badge badge-secondary-lighten mb-1">', true, '无标签'); ?></span>  <span class="badge badge-success mb-1"><?php $this->date('Y-m-j'); ?></span>
  <span class="badge badge-success mb-1">阅读：<?php get_post_view($this) ?></span>

<div class="post-content mt-2">
<?php if ($this->fields->st == '1' && !$this->user->hasLogin()): ?>
<div class="alert alert-danger mt-2" role="alert">
该内容登录后可见
</div>
<?php else: ?>
<?php if($this->hidden||$this->titleshow): ?>
<?php if($this->jianrong==1): ?>
<?php $this->content(); ?>
<form action="<?php echo Typecho_Widget::widget('Widget_Security')->getTokenUrl($this->permalink); ?>" method="post" class="protected">
<div class="form-group mb-3">
<label>请输入密码访问</label>
<div class="input-group">
<input  type="password" class="text" name="protectPassword" class="form-control" placeholder="请输入密码" aria-label="请输入密码"><input type="hidden" name="protectCID" value="<?php $this->cid(); ?>" />
<div class="input-group-append">
<button class="btn btn-primary" type="submit">提交</button>
</div>
</div>
</div>
</form>
<?php else: ?>
<form action="<?php echo Typecho_Widget::widget('Widget_Security')->getTokenUrl($this->permalink); ?>" method="post" class="protected">
<div class="form-group mb-3">
<label>请输入密码访问</label>
<div class="input-group">
<input  type="password" class="text" name="protectPassword" class="form-control" placeholder="请输入密码" aria-label="请输入密码"><input type="hidden" name="protectCID" value="<?php $this->cid(); ?>" />
<div class="input-group-append">
<button class="btn btn-primary" type="submit">提交</button>
</div>
</div>
</div>
</form>
<?php endif;?>
<?php else: ?>
<?php $this->content(); ?><?php endif;?></div>


<?php if (!empty($this->options->tools) && !in_array('banquan', $this->options->tools)): ?>
<!--版权声明开始-->
<div class="card ribbon-box m-0 mt-3">
<div class="card-body">
<div class="ribbon ribbon-danger float-left"><i class="mdi mdi-copyright mr-1"></i> 版权声明</div>
<div class="mb-1 shadow-none ribbon-content">
<p>本文基于《<a target="_blank" rel="external nofollow" href="https://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh">署名-非商业性使用-相同方式共享 4.0 国际 (CC BY-NC-SA 4.0)</a>》许可协议授权
<br>
文章链接：<?php $this->permalink() ?> (转载时请注明本文出处及文章链接)</p>
</div>
</div>
</div>
<!--版权声明结束-->
<?php endif;?>

<?php endif;?>

<?php if (!empty($this->options->tools) && !in_array('dashang', $this->options->tools)): ?>
<!--打赏开始-->
<div class="text-center">
<button type="button" class="btn btn-primary mr-1 mt-3" data-toggle="modal" data-target="#alipayshang">
<i class="mdi mdi-qrcode"></i> 支付宝打赏
</button>

<button type="button" class="btn btn-primary mr-1 mt-3" data-toggle="modal" data-target="#wxpayshang">
<i class="mdi mdi-qrcode-plus"></i> 微信打赏
</button>
<p class="text-muted m-b-15">如果觉得我的文章对你有用，请随意赞赏</p>
</div>

<div id="alipayshang" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="success-header-modalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header modal-colored-header bg-success">
<h4 class="modal-title mt-0" id="success-header-modalLabel"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="mdi mdi-gift"></i> 打赏一下，感谢您的支持！</font></font></h4>
<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
</div>
<div class="modal-body">
<div class="text-center"><img src="<?php if ($this->options->zhifubao): ?><?php $this->options->zhifubao(); ?><?php else: ?><?php echo theurl; ?>img/tb.png<?php endif;?>" width="200px" height="200px">
</div></div>
<div class="modal-footer">
<button type="button" class="btn btn-light" data-dismiss="modal"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="mdi mdi-reply"></i> 取消</font></font></button>
 </div>
</div>
</div>
</div>

<div id="wxpayshang" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="success-header-modalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header modal-colored-header bg-success">
<h4 class="modal-title mt-0" id="success-header-modalLabel"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="mdi mdi-gift"></i> 打赏一下，感谢您的支持！</font></font></h4>
<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
</div>
<div class="modal-body">
<div class="text-center"><img src="<?php if ($this->options->weixin): ?><?php $this->options->weixin(); ?><?php else: ?><?php echo theurl; ?>img/wx.png<?php endif;?>" width="200px" height="200px">
</div></div>
<div class="modal-footer">
<button type="button" class="btn btn-light" data-dismiss="modal"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="mdi mdi-reply"></i> 取消</font></font></button>
 </div>
</div>
</div>
</div>
<!--打赏结束-->
<?php endif;?>

</div> 
</div> 
<div class="mb-3">
<?php thePrev($this,'没有了'); ?>
<?php theNext($this,'没有了'); ?>
</div> 

<?php if(!$this->request->isAjax()): ?><?php if($this->options->ad): ?>
<div class="card d-block">
<div class="card-body">
<?php $this->options->ad(); ?>
</div> 
</div><?php endif; ?><?php endif; ?>

<?php $this->need('comments.php'); ?>

</div> 


<?php if(!$this->request->isAjax()): ?>
<?php $this->need('post-sidebar.php'); ?>
<?php endif;?>











</div>

</div>







<?php endif;?>

<?php if(!$this->request->isAjax()): ?>
<?php $this->need('footer.php'); ?>
<?php endif;?>