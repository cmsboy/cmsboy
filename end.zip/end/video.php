<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<div class="container-fluid mt-4">

<div class="row">
<div class="col-md-12">

<h3 class="mt-0">
<?php $this->title(); ?>
</h3>
<span class="badge badge-primary-lighten mb-1">
<?php $this->category('</span> <span class="badge badge-primary-lighten mb-1">', true, '无分类'); ?></span>
<span class="badge badge-secondary mb-1">
<?php $this->tags('</span>  <span class="badge badge-secondary mb-1">', true, 'none'); ?></span> <span class="badge badge-success mb-1"><?php $this->date('Y-m-j'); ?></span>  <span class="badge badge-success mb-1">观看：<?php get_post_view($this) ?></span></div>

<div class="col-md-8">

<div class="mb-3">

<?php if ($this->fields->st == '1' && !$this->user->hasLogin()): ?>

<div class="alert alert-danger mt-2" role="alert">
当前视频需要登录后才能观看
</div>
<?php else: ?>
<?php if($this->hidden||$this->titleshow): ?>
<form action="<?php echo Typecho_Widget::widget('Widget_Security')->getTokenUrl($this->permalink); ?>" method="post" class="mt-2 protected">
<div class="form-group mb-3">
<label>当前视频需要输入密码才能观看</label>
<div class="input-group">
<input  type="password" class="text" name="protectPassword" class="form-control" placeholder="请输入密码" aria-label="请输入密码"><input type="hidden" name="protectCID" value="<?php $this->cid(); ?>" />
<div class="input-group-append">
<button class="btn btn-primary" type="submit">提交</button>
</div>
</div>
</div>
</form>
<?php else: ?>

<?php if ($this->fields->mp4||$this->fields->m3u8): ?>

<?php 
          //$geturl = $this->fields->iframe;$str1 = explode('aid=', $geturl);$str2 = explode('&cid=', $str1[1]);$av = $str2[0];
          ?>

<?php
$duoji="";
$list="";
if($this->fields->duoji && strpos($this->fields->duoji,'$') !== false){

$hang = explode("\r\n", $this->fields->duoji);
$shu=count($hang);

for($i=0;$i<$shu;$i++){
$cid=explode("$",$hang[$i])[1];
$this->widget('Widget_Archive@duoji'.$cid, 'pageSize=1&type=post', 'cid='.$cid)->to($ji); 

if($ji->cid==$this->cid){
$duoji=$duoji."<span class=\"btn btn-outline-danger btn-sm ml-1 border-0 disabled\">".explode("$",$hang[$i])[0]."</span>";
}else{
$duoji=$duoji."<a href=\"".$ji->permalink."\" class=\"btn btn-outline-danger btn-sm ml-1 border-0\">".explode("$",$hang[$i])[0]."</a>";
}
}

}


if($this->fields->m3u8){
				$spurl=$this->fields->m3u8;
				$qin_zz='/<li><.*?>/';
				$qin_yuan=file_get_contents($spurl); 
				$qin_f1=explode("m3u8</span></h3>",$qin_yuan);
				$qin_f2=explode("</ul>",$qin_f1[1]);
				$qin_f3=preg_split($qin_zz,$qin_f2[0]);
				$qin_p1=count($qin_f3);
				for($a=1;$a<$qin_p1;$a++)
				{
					$qin_ge=explode("m3u8</li>",$qin_f3[$a]);
					$qin_ji=$qin_ji.$qin_ge[0]."m3u8\r\n";
				}
				$x=0;
				if(strpos($qin_ji,'$') !== false)
				{
					$j=0;
					if(isset($_GET['action']))
					{
						if($_GET['action'] == 'get' && 'GET' == $_SERVER['REQUEST_METHOD'] )
						{
							$j=$_GET['p']-1;
						}
					}
					$txt=$qin_ji;
					$string_arr = explode("\r\n", $txt);
					$long=count($string_arr);
					for($i=0;$i<$long;$i++)
					{if(count(explode("$",$string_arr[$i]))>1){
						if($j==$i)
						{
							$c="class=\"btn btn-primary c\"";}else{$c="class=\"btn btn-outline-primary\"";
						}
						$p=$i+1;
						$list=$list."<a href=\"".$this->permalink."?action=get&p=".$p."\"".$c.">".explode("$",$string_arr[$i])[0]."</a>";}
					}
					$list= '<div class="card d-block mb-3"><div class="card-header"><span>剧集</span>'.$duoji.'</div>
<div class="card-body button-list">'.$list.'</div></div>';
					$spurl=explode("$",$string_arr[$j])[1];
				}
				$qin_j1=explode("剧情介绍：</strong>",$qin_f1[0]);
				$qin_j2=explode("</div>",$qin_j1[1]);
				$qin_j3=explode(">",$qin_j2[1]);
				$qin_js=$qin_j2[1];
			}else{


$spurl=$this->fields->mp4;
$x=0;
if(strpos($this->fields->mp4,'$') !== false){

$j=0;
if(isset($_GET['action'])){
if($_GET['action'] == 'get' && 'GET' == $_SERVER['REQUEST_METHOD'] ) {
$j=$_GET['p']-1;
}}

$txt=$this->fields->mp4;

$string_arr = explode("\r\n", $txt);
$long=count($string_arr);
$list="";
for($i=0;$i<$long;$i++){

if(count(explode("$",$string_arr[$i]))>1){

if($j==$i){$c="class=\"btn btn-primary c\"";}else{$c="class=\"btn btn-outline-primary\"";}
$p=$i+1;
$list=$list."<a href=\"".$this->permalink."?action=get&p=".$p."\"".$c.">".explode("$",$string_arr[$i])[0]."</a>";
}
}
$list= '<div class="card d-block mb-3"> <div class="card-header"><span>剧集</span>'.$duoji.'</div>
<div class="card-body button-list">'.$list.'</div></div>';


$spurl=explode("$",$string_arr[$j])[1];


if(isset(explode("$",$string_arr[$j])[2])){
$zimu=explode("$",$string_arr[$j])[2];
}


}}
?>
<style>
.vid-wrapper{
width:100%;
position:relative;
padding-bottom:56.25%;
height: 0;
}
#dplayer{
position: absolute;
top:0;
left: 0;
width: 100%;
height: 100%
}
.dplayer-menu>div:nth-last-child(-n+2) {
    display: none;
}
</style>
<div class="vid-wrapper">



<?php if(strpos($this->fields->mp4,'player.bilibili.com') !== false): ?>
<style>
.vid-wrapper{
padding-bottom:68%;
}
</style>
<div id="dplayer">
<iframe width="100%" height="100%" src="<?php echo $spurl; ?>&as_wide=1&high_quality=1&danmaku=0" frameborder="0" border="0" marginwidth="0" marginheight="0" scrolling="no" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen"  sandbox="allow-top-navigation allow-same-origin allow-forms allow-scripts"></iframe>
</div>



<?php else: ?>

<?php if ($this->options->jxurl): ?>
<div id="dplayer">
<iframe width="100%" height="100%" src="<?php $this->options->jxurl(); ?><?php echo $spurl; ?>" frameborder="0" border="0" marginwidth="0" marginheight="0" scrolling="no" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen"></iframe>
</div>
<?php else: ?>

<?php if(strpos($spurl, '.flv')) {echo '<script src="https://cdn.jsdelivr.net/npm/flv.js/dist/flv.min.js"></script>';}
if(strpos($spurl, 'magnet:')) {echo '<script src="https://cdn.jsdelivr.net/webtorrent/latest/webtorrent.min.js"></script>';} ?>
<script src="https://cdn.jsdelivr.net/npm/hls.js/dist/hls.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/dplayer/dist/DPlayer.min.js"></script>
<div id="dplayer"></div>
<script>
    var webdata = {
        set:function(key,val){
            window.sessionStorage.setItem(key,val);
        },
        get:function(key){
            return window.sessionStorage.getItem(key);
        },
        del:function(key){
            window.sessionStorage.removeItem(key);
        },
        clear:function(key){
            window.sessionStorage.clear();
        }
    };
var vurl='<?php echo $spurl; ?>';
const dp = new DPlayer({
                container: document.getElementById('dplayer'),
                screenshot: false,lang: 'zh-cn',hotkey: true,preload: 'auto',
                video: {
                 url: vurl,type: 'auto',
                 pic: 'https://wxt.sinaimg.cn/large/87c01ec7gy1fqhvm91iodj21hc0u046d.jpg',
                }, 
<?php if(isset($zimu)): ?>
 subtitle: {
        url: '<?php echo $zimu; ?>',
        type: 'webvtt',
        fontSize: '25px',
        bottom: '10%',
        color: '#b7daff',
    },
<?php endif; ?>
   contextmenu: [
        {
            text: '画中画',
            click: (player) => {
player.video.requestPictureInPicture();
            },
        },
    ],             
       });
   dp.seek(webdata.get('pay'+vurl));
    setInterval(function(){
        webdata.set('pay'+vurl,dp.video.currentTime);
    },1000);
</script>
<?php endif; ?><?php endif; ?>
</div>




<?php endif; ?><?php endif;?><?php endif; ?>



</div>

<?php echo $list; ?>

<div class="card d-block mb-3">


<div class="card-body">
<?php if($this->hidden||$this->titleshow): ?><?php else: ?>
<div class="post-content mt-2">
<?php 
if($this->fields->mp4){$this->content();}else{echo $qin_js.'</div>';}
?>
</div>
<?php endif;?>







<?php if (!empty($this->options->tools) && !in_array('dashang', $this->options->tools)): ?>
<!--打赏开始-->
<div class="text-center">
<button type="button" class="btn btn-primary mr-1 mt-3" data-toggle="modal" data-target="#alipayshang">
<i class="mdi mdi-qrcode"></i> 支付宝打赏
</button>

<button type="button" class="btn btn-primary mr-1 mt-3" data-toggle="modal" data-target="#wxpayshang">
<i class="mdi mdi-qrcode-plus"></i> 微信打赏
</button>
<p class="text-muted mb-0">如果觉得我的文章对你有用，请随意赞赏</p>
</div>

<div id="alipayshang" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="success-header-modalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header modal-colored-header bg-success">
<h4 class="modal-title mt-0" id="success-header-modalLabel"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="mdi mdi-gift"></i> 打赏一下，感谢您的支持！</font></font></h4>
<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
</div>
<div class="modal-body">
<div class="text-center"><img src="<?php if ($this->options->zhifubao): ?><?php $this->options->zhifubao(); ?><?php else: ?><?php echo theurl; ?>img/tb.png<?php endif;?>" width="200px" height="200px">
</div></div>
<div class="modal-footer">
<button type="button" class="btn btn-light" data-dismiss="modal"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="mdi mdi-reply"></i> 取消</font></font></button>
 </div>
</div>
</div>
</div>

<div id="wxpayshang" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="success-header-modalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header modal-colored-header bg-success">
<h4 class="modal-title mt-0" id="success-header-modalLabel"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="mdi mdi-gift"></i> 打赏一下，感谢您的支持！</font></font></h4>
<button type="button" class="close" data-dismiss="modal" aria-hidden="true"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">×</font></font></button>
</div>
<div class="modal-body">
<div class="text-center"><img src="<?php if ($this->options->weixin): ?><?php $this->options->weixin(); ?><?php else: ?><?php echo theurl; ?>img/wx.png<?php endif;?>" width="200px" height="200px">
</div></div>
<div class="modal-footer">
<button type="button" class="btn btn-light" data-dismiss="modal"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><i class="mdi mdi-reply"></i> 取消</font></font></button>
 </div>
</div>
</div>
</div>
<!--打赏结束-->
<?php endif;?>




</div> 

</div>
 
<div class="mb-3">
<?php thePrev($this,'没有了'); ?>
<?php theNext($this,'没有了'); ?>
</div> 
<?php $this->need('comments.php'); ?>

<?php if(!$this->request->isAjax()): ?><?php if($this->options->ad): ?>
<div class="card d-block">
<div class="card-body">
<?php $this->options->ad(); ?>
</div> 
</div><?php endif; ?><?php endif; ?>

</div> 
<?php if(!$this->request->isAjax()): ?>
<?php $this->need('post-sidebar.php'); ?>
<?php endif;?>

</div>
</div>