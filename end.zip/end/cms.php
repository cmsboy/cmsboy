<?php $n=0; if($this->have()): ?>
<?php while($this->next()): ?>
<?php $n++; if($n>6){break;} ?>
<div class="col-6 col-md-4 col-lg-2 mb-3">
<div class="ze-over">
<a href="<?php $this->permalink();?>"><img class="b-lazy" src="<?php echo theurl; ?>img/load.gif" data-url="<?php showThumbnail($this); ?>" alt="<?php $this->title();?>"></a>
<a href="<?php $this->permalink();?>"><div class="zeze-over"><span class="title"><?php $this->sticky(); 
 $this->title();?></span></div></a>
</div></div>


<?php endwhile; endif;?>

<?php 
$txt=$this->options->cms;
$string_arr = explode("\r\n", $txt);
$long=count($string_arr);
?>
<?php 
for($i=0;$i<$long;$i++){
$id=explode("$",$string_arr[$i])[0];
$biaoti=explode("$",$string_arr[$i])[1];
$ys=explode("$",$string_arr[$i])[2];
?>
<?php if(is_numeric($id)): ?>

<?php if($ys==1): ?>
<?php $this->widget('Widget_Archive@index'.$i, 'pageSize=10&type=category', 'mid='.$id)->to($new); ?>
<div class="col-12"><div class="mb-2 p-0"><h4><?php echo $biaoti; ?><a class="float-right" href="<?php echo $new->_pageRow["permalink"]; ?>">更多</a></h4></div></div>
<?php while ($new->next()): ?>
<div class="col-6 col-md-1-5">
<div class="card d-block"><div class="card-img-bili">
<a href="<?php $new->permalink() ?>"><img class="card-img-top b-lazy" src="<?php echo theurl; ?>img/load.gif" data-url="<?php showThumbnail($new); ?>" alt="<?php $new->title(); ?>"></a></div> 
<div class="card-body">
<a href="<?php $new->permalink() ?>"><h5 class="card-title"><?php $new->title(); ?></h5></a>
<p class="card-text slr"><?php $new->excerpt(90, ''); ?></p>
</div> 
</div> 
</div>
<?php endwhile; ?>
<?php endif;?>

<?php if($ys==2): ?>
<?php $this->widget('Widget_Archive@index'.$i, 'pageSize=5&type=category', 'mid='.$id)->to($new); ?>
<div class="col-12 col-md-6">
<div class="card"><div class="card-body">
<h5 class="card-title mb-3"><?php echo $biaoti; ?><a class="float-right" href="<?php echo $new->_pageRow["permalink"]; ?>">更多</a></h5>  
<?php while ($new->next()): ?>
<div class="media mb-2">
<a href="<?php $new->permalink() ?>" title="<?php $new->title(); ?>">
<img class="avatar-sm" style="object-fit: cover;" src="<?php showThumbnail($new); ?>" alt="image"></a>
<div class="media-body ml-2">
<a href="<?php $new->permalink() ?>" title="<?php $new->title(); ?>"> <h4 class="mb-1 mt-1 huise slr"><?php $new->title(); ?></h4></a>
<p class="mb-0 slr"><?php $new->excerpt(90, ''); ?></p>
</div> <!-- end media-body -->
</div> <!-- end media -->
<?php endwhile; ?>                                                 
</div>
</div>
</div>
<?php endif;?>


<?php if($ys==3): ?>
<?php $this->widget('Widget_Archive@index'.$i, 'pageSize=6&type=category', 'mid='.$id)->to($new); ?>
<div class="col-12"><div class="mb-2 p-0"><h4><?php echo $biaoti; ?><a class="float-right" href="<?php echo $new->_pageRow["permalink"]; ?>">更多</a></h4></div></div>
<?php while ($new->next()): ?>
<div class="col-6 col-md-4 col-lg-2 mb-3">
<div class="ze-over">
<a href="<?php $new->permalink() ?>"><img src="<?php showThumbnail($new); ?>" alt="<?php $new->title(); ?>"></a>
<a href="<?php $new->permalink() ?>"><div class="zeze-over"><span class="title"><?php $new->title(); ?></span></div></a>
</div></div>
<?php endwhile; ?> 
<?php endif;?>

<?php if($ys==4): ?>
<?php $this->widget('Widget_Archive@index'.$i, 'pageSize=6&type=category', 'mid='.$id)->to($new); ?>
<div class="col-12"><div class="mb-2 p-0"><h4><?php echo $biaoti; ?><a class="float-right" href="<?php echo $new->_pageRow["permalink"]; ?>">更多</a></h4></div></div>
<?php while ($new->next()): ?>
<div class="col-6 col-md-4">
<div class="card d-block">
<div class="card-body">
<a href="<?php $new->permalink() ?>"><h5 class="card-title mb-0"><?php $new->title(); ?></h5></a>
<p class="card-text slr"><?php $new->excerpt(90, ''); ?></p>
<a href="<?php $new->permalink() ?>" class="btn btn-secondary">阅读文章</a>
</div> 
</div> 
</div>
<?php endwhile; ?> 
<?php endif;?>


<?php if($ys==5): ?>
<?php $this->widget('Widget_Archive@index'.$i, 'pageSize=6&type=category', 'mid='.$id)->to($new); ?>
<div class="col-12"><div class="mb-2 p-0"><h4><?php echo $biaoti; ?><a class="float-right" href="<?php echo $new->_pageRow["permalink"]; ?>">更多</a></h4></div></div>
<?php while ($new->next()): ?>
<div class="col-6 col-md-4 col-lg-4 col-xl-2 mb-3">
<div class="ze-over">
<a href="<?php $new->permalink() ?>"><img class="h300 b-lazy" src="<?php echo theurl; ?>img/load.gif" data-url="<?php showThumbnail($new); ?>" alt="<?php $new->title(); ?>"></a>
<div class="tvtv-over"><a href="<?php $new->permalink() ?>"><span class="title"><?php $new->title(); ?></span></a></div>
</div>
</div>
<?php endwhile; ?> 
<?php endif;?>

<?php if($ys==6): ?>
<?php $this->widget('Widget_Archive@index'.$i, 'pageSize=12&type=category', 'mid='.$id)->to($new); ?>
<div class="col-12"><div class="mb-2 p-0"><h4><?php echo $biaoti; ?><a class="float-right" href="<?php echo $new->_pageRow["permalink"]; ?>">更多</a></h4></div></div>
<?php while ($new->next()): ?>
<div class="col-6 col-md-4 col-lg-4 col-xl-2 mb-3">
<div class="ze-over">
<a href="<?php $new->permalink() ?>"><img class="h300 b-lazy" src="<?php echo theurl; ?>img/load.gif" data-url="<?php showThumbnail($new); ?>" alt="<?php $new->title(); ?>"></a>
<div class="tvtv-over"><a href="<?php $new->permalink() ?>"><span class="title"><?php $new->title(); ?></span></a></div>
</div>
</div>
<?php endwhile; ?> 
<?php endif;?>


<?php else: ?>
<div class="col-12 mb-3 ze-over"><a target="_blank" href="<?php echo $ys; ?>"><img style="height: auto;max-height: 200px;min-height: 50px;object-fit: unset;" src="<?php echo $biaoti; ?>"></a></div>
<?php endif;?>

<?php } ?>




