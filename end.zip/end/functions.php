<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
require_once("lib/url.php");
require_once("lib/tool.php");
function themeConfig($form) {
    $db     = Typecho_Db::get();
    $prefix = $db->getPrefix();
    if (!array_key_exists('views', $db->fetchRow($db->select()->from('table.contents')->page(1,1)))) {
        $db->query('ALTER TABLE `' . $prefix . 'contents` ADD `views` INT(10) DEFAULT 1;');
    }
?>
<link href="<?php echo theurl; ?>lib/css.css?20201012" rel="stylesheet" type="text/css" />
<div id="tab-f" class="col-mb-12" role="complementary"><ul class="typecho-option-tabs clearfix">
<li class="w-40" id="home" onclick="return Tabs.qie('home');" style="background:#b1b1b1;"><a>主设置</a></li>
<li class="w-40" id="setc" onclick="return Tabs.qie('setc');"><a>评论过滤设置</a></li>
<li class="w-20" id="helpme" onclick="return Tabs.qie('helpme');"><a style="color: red;">帮助文档</a></li>
</ul></div>
<?php require_once("lib/backup.php"); ?>
<script src="<?php echo theurl; ?>lib/js.js?20201217"></script>
<div class="col-mb-12 typecho-option helpme" id="typecho-option-item-helpme">
<div class="typecho-page-title">
    <h3>关于自定义文章描述与关键字</h3>
</div>
<div class="typecho-table-wrap">
后台文章编辑页面，自定义字段右侧有个<code>TDK</code>按钮，点击后可以根据提示填写内容，一个优质的文章描述和一些有效的文章关键词能够大大提高收录量。
</div>
<div class="typecho-page-title">
    <h3>关于友链页面的建立</h3>
</div>
<div class="typecho-table-wrap">
首先需要安装友链插件：<a target="_blank" href="http://www.imhan.com/archives/typecho-links/" rel="external nofollow">点击下载</a>
<br>
然后新建独立页面，页面模板选择<code>links</code>，发布页面，然后在友链插件设置里，填写友链信息即可；友情链接的分类写“首页”即可将该友情链接显示在首页
</div>

<div class="typecho-page-title">
    <h3>关于置顶功能</h3>
</div>
<div class="typecho-table-wrap">
首先需要安装置顶插件：<a target="_blank" href="https://qqdie.com/archives/sticky-typecho-plugin.html" rel="external nofollow">点击下载</a>
<br>
然后在插件设置里添加置顶文章的id即可，请务必保证id填写正确否则布局会乱。
</div>


<div class="typecho-page-title">
    <h3>关于高级搜索功能</h3>
</div>
<div class="typecho-table-wrap">
首先需要安装插件：<a target="_blank" href="https://github.com/jrotty/soso" rel="external nofollow">点击下载</a>
<br>
然后在模板设置处开启高级搜索功能即可，目前高级搜索功能只有电脑端和平板端可见
</div>

<div class="typecho-page-title">
    <h3>Rdog权限狗多用户辅助插件</h3>
</div>
<div class="typecho-table-wrap">
多用户辅助插件：<a target="_blank" href="https://github.com/jrotty/Rdog" rel="external nofollow">点击下载</a>
<br>
如果你需要用户在前台注册时可以设置密码请使用该插件，同时该插件还有一些其他特性，详见插件简介。<br>
注意：如果你使用了tepass插件请务必禁用rdog插件，因为tepass插件已经继承了rdog插件的功能了，并且还会事实同步vip用户，如果不禁用rdog可能会导致vip用户同步失败
</div>

<div class="typecho-page-title">
    <h3>关于QQ登陆微博登录功能</h3>
</div>
<div class="typecho-table-wrap">
需要安装<a href="https://lixianhua.com/teconnect_plugin_for_typecho.html" rel="external nofollow" class="url">TeConnect</a>插件，并正确配置插件所需要的参数，然后在模板设置处打开前台显示QQ/微博登录按钮即可，登录按钮会显示在登录页面和评论表情按钮右侧
</div>


<div class="typecho-page-title">
<h3>自定义字段说明</h3>
</div>
<div class="typecho-table-wrap">
<table class="typecho-list-table">
<colgroup>
<col width="25%">
<col width="25%">
<col width="50%">
</colgroup>
<thead>
<tr>
 <th>字段</th>
 <th>字段值</th>
 <th>作用</th>
</tr>
</thead>
<tbody>            	                                                        
<tr>
 <td>fm</td>
 <td>图片地址</td>
 <td>自定义文章封面图</td>
</tr>
<tr>
 <td>mp4</td>
 <td>单个视频直接填写视频链接即可，多集的话按如下格式填写：<br>第一集$视频地址<br>第二集$视频地址<br>...</td>
 <td>支持MP4与m3u8</td>
</tr>
<tr>
 <td>mp4</td>
 <td>多集视频还可以加入字幕，按如下格式填写：<br>第一集$视频地址$字幕链接<br>第二集$视频地址$字幕链接<br>...</td>
 <td>视频支持MP4与m3u8，字幕支持webvtt格式，如果你使用视频解析功能，字幕功能将失效！</td>
</tr>
<tr>
 <td>m3u8</td>
 <td>直接填视频资源站的页面地址，按如下格式填写：<br>http://okzyw.net/?m=vod-detail-id-50120.html</td>
 <td>模板将自动从资源站提取视频列表，以后就不用手动更新视频了，缺点根据资源站的速度而定可能会拖慢页面加载速度</td>
</tr>
<tr>
 <td>duoji</td>
 <td>为视频设置多季显示，格式如：<br>第一季$文章cid<br>第二季$文章cid<br>...</td>
 <td>在使用mp4字段的文章时可以使用该字段设置多季视频入口</td>
</tr>
</tbody>
</table>
</div>

<div class="typecho-page-title">
    <h3>文章中插入按钮</h3>
</div>
<div class="typecho-table-wrap">
<b>[btn url="链接地址"]显示文字[/btn]</b><br>
按照上边的格式写入文章中即可，如果连续写入两个按钮的话，中间请加个空格【如果你使用第三方编辑器插件，该功能可能无法正常使用】
</div>



<div class="typecho-page-title">
    <h3>插件冲突解决方案</h3>
</div>
<div class="typecho-table-wrap">
<b>（InvitationCode）邀请码插件和（Rdog）权限狗插件的兼容处理</b>：同时禁用两个插件，先启动邀请码插件，然后在启动权限狗插件，否则会出现不兼容情况，导致用户注册完账号密码瞬间失效无法登录！<br>
不兼容LoveKKComment邮件提醒插件</b>：可换用其他邮件提醒插件，比如：<a target="_blank" href="https://gitee.com/HoeXhe/typecho-Comment2Mail" rel="external nofollow">Comment2Mail</a>
</div>

<div class="typecho-page-title">
<h3>相对上一版本更新了以下内容</h3>
</div>
<div class="typecho-table-wrap">
1，解决万篇文章时某些数据库语句导致文章加载变慢的问题<br>
2，取消之前版本资源路径对多域名的支持，避免其他bug<br>
3，兼容teadmin插件夜间模式<br>
4，其他
</div>
</div>
<?php
    $logoUrl = new Typecho_Widget_Helper_Form_Element_Text('logoUrl', NULL, NULL, _t('站点 LOGO 地址'), _t('在这里填入一个图片 URL 地址, 图片尺寸要求：156 × 50'));$logoUrl->setAttribute('class', 'col-mb-12 typecho-option home');
    $form->addInput($logoUrl);

    $tools = new Typecho_Widget_Helper_Form_Element_Checkbox('tools', 
    array(
'qzlogin' => _t('禁止游客评论（评论需登录）'),
'commentsnourl' => _t('评论区隐藏网址输入框同时隐藏评论列表用户昵称超链接'),
'pagelist' => _t('翻页按钮改为数字形式'),
'fancybox' => _t('开启fancybox图片灯箱插件'),
'prism' => _t('开启主题默认的prism.js代码高亮组件'),
'linkin' => _t('文章中外链自动转内链跳转，江湖传言有利于SEO(如果您使用cdn请务必关闭此功能，否则将引起bug)'),
'soso' => _t('开启高级搜索功能，需要安装<a href="https://github.com/jrotty/soso" rel="external nofollow" class="url">soso插件</a>'),
'QQConnect' => _t('前台显示QQ登陆按钮，开启前请安装并配置好<a href="https://lixianhua.com/teconnect_plugin_for_typecho.html" rel="external nofollow" class="url">TeConnect</a>插件'),
'weiboConnect' => _t('前台显示微博登陆按钮，开启前请安装并配置好<a href="https://lixianhua.com/teconnect_plugin_for_typecho.html" rel="external nofollow" class="url">TeConnect</a>插件'),
'pixiv' => _t('文章侧栏显示Pixiv每日Top50小部件【api来自<a href="https://www.mokeyjay.com/archives/1063" rel="external nofollow" class="url">mokeyjay</a>】'),
'gotop' => _t('关闭返回顶部按钮'),
'postsidebarbg' => _t('关闭热门文章推荐文章美化效果'),
'banquan' => _t('关闭文章底部版权提示'),
'dashang' => _t('关闭文章底部打赏按钮'),
'biaoqing' => _t('关闭评论表情功能'),
),
    array('prism','fancybox'), _t('<span onclick="bian()">拓展设置</span>'));$tools->setAttribute('class', 'col-mb-12 typecho-option home');
    $form->addInput($tools->multiMode());


$zhifubao = new Typecho_Widget_Helper_Form_Element_Textarea('zhifubao', NULL,NULL,'支付宝收款二维码', _t('请填写二维码图片地址，尺寸200x200或者等比例'));$zhifubao->setAttribute('class', 'col-mb-6 home');
$form->addInput($zhifubao);


$weixin = new Typecho_Widget_Helper_Form_Element_Textarea('weixin', NULL,NULL,'微信收款二维码', _t('请填写二维码图片地址，尺寸200x200或者等比例'));$weixin->setAttribute('class', 'col-mb-6 home');
$form->addInput($weixin);

$jxurl = new Typecho_Widget_Helper_Form_Element_Text('jxurl', NULL, NULL, _t('视频解析功能'), _t('填写视频解析地址，不填写模板视频功能仅支持播放mp4，m3u8和flv视频直链'));$jxurl->setAttribute('class', 'col-mb-12 typecho-option home');
$form->addInput($jxurl);


 $gravatars = new Typecho_Widget_Helper_Form_Element_Select('gravatars', array(
'www.gravatar.com/avatar' => _t('gravatar的www源'),'cn.gravatar.com/avatar' => _t('gravatar的cn源'),'secure.gravatar.com/avatar' => _t('gravatar的secure源'),'sdn.geekzu.org/avatar' => _t('极客族'),'gravatar.proxy.ustclug.org/avatar' => _t('中科大[不建议]'),'cdn.v2ex.com/gravatar' => _t('v2ex源'),'dn-qiniu-avatar.qbox.me/avatar' => _t('七牛源[不建议]'),'gravatar.helingqi.com/wavatar' => _t('禾令奇[建议]'),'gravatar.loli.net/avatar' => _t('loli.net源'),
'cdn.zhuchunshu.com/avatar'=>_t('朱纯树网友自建')

    ), 'gravatar.helingqi.com/wavatar',
    _t('gravatar头像源'), _t('默认gravatar.helingqi.com/wavatar')); $gravatars->setAttribute('class', 'col-mb-6 home');
    $form->addInput($gravatars->multiMode());



 $fwidth = new Typecho_Widget_Helper_Form_Element_Select('fwidth', array(
'0' => _t('流布局'),
'1' => _t('盒子布局')
    ), '0',
    _t('页面布局设置'), _t('默认流布局')); $fwidth->setAttribute('class', 'col-mb-6 home');
    $form->addInput($fwidth->multiMode());

 $fengge = new Typecho_Widget_Helper_Form_Element_Select('fengge', array(
'1' => _t('垂直布局'),
'2' => _t('水平布局')
    ), '2',
    _t('导航布局设置'), _t('默认水平布局')); $fengge->setAttribute('class', 'col-mb-6 home');
    $form->addInput($fengge->multiMode());

 $leftsidebar = new Typecho_Widget_Helper_Form_Element_Select('leftsidebar', array(
'light' => _t('明亮模式'),
'dark' => _t('暗色模式')
    ), 'light',
    _t('导航/按钮配色方案'), _t('默认渐变紫')); $leftsidebar->setAttribute('class', 'col-mb-6 home');
    $form->addInput($leftsidebar->multiMode());


 $dl = new Typecho_Widget_Helper_Form_Element_Select('dl', array(
'1' => _t('风格1'),
'2' => _t('风格2')
    ), '1',
    _t('登录注册风格'), _t('默认风格1')); $dl->setAttribute('class', 'col-mb-6 home');
    $form->addInput($dl->multiMode());



 $freestyle = new Typecho_Widget_Helper_Form_Element_Select('freestyle', array(
'3,6,12' => _t('默认模式'),
'3,6,6' => _t('422模式'),
'3,4,6' => _t('432模式'),
'3,4,12' => _t('431模式'),
'1-5,3,12' => _t('541模式'),
'1-5,3,6' => _t('542模式')
    ), '3,6,12',
    _t('文章列表控制'), _t('模式由3个数字控制，比如422模式指的就是pc端一行显示4个文章，平板模式显示2个文章，手机端显示2个文章，默认是421')); $freestyle->setAttribute('class', 'col-mb-6 home');
    $form->addInput($freestyle->multiMode());

$lunbo = new Typecho_Widget_Helper_Form_Element_Textarea('lunbo', NULL,NULL, _t('轮播图设置'), _t('填写格式是文章/独立页面cid$图片地址然后换行输入下一个'));$lunbo->setAttribute('class', 'col-mb-12 home');
$form->addInput($lunbo);

$tuijian = new Typecho_Widget_Helper_Form_Element_Text('tuijian', NULL, NULL, _t('推荐文章'), _t('轮播图右侧的推荐文章，推荐格式为三个文章cid中间用英文逗号隔开如：<code>123,456,789</code>，不填则默认显示热门文章'));$tuijian->setAttribute('class', 'col-mb-12 typecho-option home');
$form->addInput($tuijian);

$cms = new Typecho_Widget_Helper_Form_Element_Textarea('cms', NULL,NULL, _t('cms首页布局设置'), _t('当你使用cms首页时，可以在这里设置布局，格式为：分类mid$标题$样式(1,2,3,4,5,6)，然后换行输入下一个你想要展示在首页的分类，如：13$标题$1<br>同时也可以设置广告，换行按这个格式输入即可：广告$图片链接$跳转链接 '));$cms->setAttribute('class', 'col-mb-12 home');
$form->addInput($cms);

$headwen = new Typecho_Widget_Helper_Form_Element_Textarea('headwen', NULL,NULL, _t('head头部'), _t('适合填写百度统计等需要插入在head部分的代码，不适合cnzz的统计代码哦！'));$headwen->setAttribute('class', 'col-mb-12 home');
$form->addInput($headwen);

$bodywen = new Typecho_Widget_Helper_Form_Element_Textarea('bodywen', NULL,NULL, _t('body尾部自定义html'), _t('自定义html代码会输入到<code>&lt;/body&gt;</code>前面'));$bodywen->setAttribute('class', 'col-mb-12 home');
$form->addInput($bodywen);


$footerwen = new Typecho_Widget_Helper_Form_Element_Textarea('footerwen', NULL,NULL, _t('底部左侧文字'), _t('可以写些备案信息，cnzz统计代码什么的，不填则不显示'));$footerwen->setAttribute('class', 'col-mb-12 home');
$form->addInput($footerwen);

$footerwen2 = new Typecho_Widget_Helper_Form_Element_Textarea('footerwen2', NULL,NULL, _t('底部右侧文字'), _t('可以写些备案信息，cnzz统计代码什么的，不填则不显示'));$footerwen2->setAttribute('class', 'col-mb-12 home');
$form->addInput($footerwen2);




$stxt = new Typecho_Widget_Helper_Form_Element_Text('stxt', NULL, NULL, _t('缩略图后缀'), _t('这里可以设置文章缩略图地址的后缀，方便使用云存储的朋友设置裁剪规则'));$stxt->setAttribute('class', 'col-mb-12 typecho-option home');
$form->addInput($stxt);

$mos = new Typecho_Widget_Helper_Form_Element_Textarea('mos', NULL,NULL, _t('默认缩略图设置'), _t('填写图片地址，一行一个图片地址，文章中没有图片时将随机使用这里面的图片地址，不填写则使用程序内置的图片'));$mos->setAttribute('class', 'col-mb-12 home');
$form->addInput($mos);


//广告位
$ad = new Typecho_Widget_Helper_Form_Element_Textarea('ad', NULL,NULL,'评论列表上方广告', _t('可直接填入谷歌广告，或者按这个格式填入自定义广告&lt;a href="广告链接" target="_blank"&gt;&lt;img src="广告图片"&gt;&lt;/a&gt;&gt;'));$ad->setAttribute('class', 'col-mb-6 home');
$form->addInput($ad);


//广告位
$ads = new Typecho_Widget_Helper_Form_Element_Textarea('ads', NULL,NULL,'文章右侧栏广告1', _t('可直接填入谷歌广告，或者按这个格式填入自定义广告&lt;a href="广告链接" target="_blank"&gt;&lt;img src="广告图片"&gt;&lt;/a&gt;&gt;'));$ads->setAttribute('class', 'col-mb-6 home');
$form->addInput($ads);

$ads2 = new Typecho_Widget_Helper_Form_Element_Textarea('ads2', NULL,NULL,'文章右侧栏广告2', _t('可直接填入谷歌广告，或者按这个格式填入自定义广告&lt;a href="广告链接" target="_blank"&gt;&lt;img src="广告图片"&gt;&lt;/a&gt;&gt;'));$ads2->setAttribute('class', 'col-mb-6 home');
$form->addInput($ads2);

$ads3 = new Typecho_Widget_Helper_Form_Element_Textarea('ads3', NULL,NULL,'文章右侧栏广告3', _t('可直接填入谷歌广告，或者按这个格式填入自定义广告&lt;a href="广告链接" target="_blank"&gt;&lt;img src="广告图片"&gt;&lt;/a&gt;&gt;'));$ads3->setAttribute('class', 'col-mb-6 home');
$form->addInput($ads3);


 $CDNURL = new Typecho_Widget_Helper_Form_Element_Text('CDNURL', NULL, NULL, _t('模板cssjs等资源文件地址替换【不建议使用】'), _t("请填写替换资源的路径地址，测试功能不建议使用"));$CDNURL->setAttribute('class', 'col-mb-12 typecho-option home');   $form->addInput($CDNURL);

//评论过滤设置，基于ajax评论而生

$opt_nocn = new Typecho_Widget_Helper_Form_Element_Radio('opt_nocn', array("none" => "无动作", "waiting" => "标记为待审核", "spam" => "标记为垃圾", "abandon" => "评论失败"), "abandon",
			_t('非中文评论操作'), "如果评论中不包含中文，则强行按该操作执行");$opt_nocn->setAttribute('class', 'col-mb-12 setc');
        $form->addInput($opt_nocn);


        $opt_url = new Typecho_Widget_Helper_Form_Element_Radio('opt_url', array("none" => "无动作", "waiting" => "标记为待审核", "spam" => "标记为垃圾", "abandon" => "评论失败"), "none",
			_t('屏蔽网址操作'), "如果评论发布者的网址与禁止的一致，将执行该操作。如果网址为空，该项不会起作用。");$opt_url->setAttribute('class', 'col-mb-12 setc');
        $form->addInput($opt_url);
        $words_url = new Typecho_Widget_Helper_Form_Element_Textarea('words_url', NULL, "",
			_t('网址关键词'), _t('多个网址请用换行符隔开<br />可以是网址的全部，或者网址部分关键词。如果网址为空，该项不会起作用。'));$words_url->setAttribute('class', 'col-mb-12 setc');
        $form->addInput($words_url);


        $opt_chk = new Typecho_Widget_Helper_Form_Element_Radio('opt_chk', array("none" => "无动作", "waiting" => "标记为待审核", "spam" => "标记为垃圾", "abandon" => "评论失败"), "none",
			_t('敏感词汇操作'), "如果评论中包含敏感词汇列表中的词汇，将执行该操作");$opt_chk->setAttribute('class', 'col-mb-12 setc');
        $form->addInput($opt_chk);

        $words_chk = new Typecho_Widget_Helper_Form_Element_Textarea('words_chk', NULL, "",
			_t('敏感词汇'), _t('多条词汇请用换行符隔开<br />注意：如果词汇同时出现于禁止词汇，则执行禁止词汇操作'));$words_chk->setAttribute('class', 'col-mb-12 setc');
        $form->addInput($words_chk);

        $opt_au = new Typecho_Widget_Helper_Form_Element_Radio('opt_au', array("none" => "无动作", "waiting" => "标记为待审核", "spam" => "标记为垃圾", "abandon" => "评论失败"), "none",
			_t('屏蔽昵称关键词操作'), "如果评论发布者的昵称含有该关键词，将执行该操作");$opt_au->setAttribute('class', 'col-mb-12 setc');
        $form->addInput($opt_au);

        $words_au = new Typecho_Widget_Helper_Form_Element_Textarea('words_au', NULL, "",
			_t('屏蔽昵称关键词'), _t('多个关键词请用换行符隔开'));$words_au->setAttribute('class', 'col-mb-12 setc');
        $form->addInput($words_au);
      
        $opt_mail = new Typecho_Widget_Helper_Form_Element_Radio('opt_mail', array("none" => "无动作", "waiting" => "标记为待审核", "spam" => "标记为垃圾", "abandon" => "评论失败"), "none",
			_t('屏蔽邮箱操作'), "如果评论发布者的邮箱与禁止的一致，将执行该操作");$opt_mail->setAttribute('class', 'col-mb-12 setc');
        $form->addInput($opt_mail);
        $words_mail = new Typecho_Widget_Helper_Form_Element_Textarea('words_mail', NULL, "",
			_t('邮箱关键词'), _t('多个邮箱请用换行符隔开<br />可以是邮箱的全部，或者邮箱部分关键词'));$words_mail->setAttribute('class', 'col-mb-12 setc');
        $form->addInput($words_mail);    
}
function themeFields($layout) {
	$st = new Typecho_Widget_Helper_Form_Element_Radio('st', array(
'0' => _t('公开'),
'1' => _t('登录可见'),
 ),'0', _t('文章状态'), _t('<style>.typecho-list-table textarea, .typecho-list-table input[type="text"] { width: 100%; }</style>'));
	$layout->addItem($st);
}